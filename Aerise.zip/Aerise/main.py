# -*- coding: utf-8 -*-
"""Aerise — Akıllı İş Başvuru Asistanı (UI katmanı).

UI, otomasyona yalnızca core.engine.Engine API'si üzerinden erişir (adapter mimarisi).
"""
import os
import shutil
import threading
import tkinter.filedialog as fd
import tkinter.messagebox as mb

import customtkinter as ctk

from core.settings import load_settings, save_settings, project_root
from core import db
from core.engine import engine, APP_NAME, APP_VERSION
from core.manager import SITE_REGISTRY
from core.updater import check_update

db.init_db()  # her giriş noktasında tablolar garanti (baslat.bat / python main.py / import)

ASSETS = os.path.join(project_root(), "assets")
ICON_PATH = os.path.join(ASSETS, "appicon.ico")      # masaustu/gorev cubugu ikonu (koyu)
LOGO_PATH = os.path.join(ASSETS, "logo_sidebar.png")  # uygulama ici logo (beyaz)

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

ACCENT = "#2563eb"
GREEN = "#16a34a"
RED = "#dc2626"
AMBER = "#d97706"
BG_CARD = ("gray92", "#1b1e27")
FONT_H = ("Segoe UI Semibold", 22)
FONT_SUB = ("Segoe UI", 13)
FONT_SM = ("Segoe UI", 12)

NAV_ITEMS = [
    ("dashboard", "🏠  Kontrol Paneli"),
    ("approval", "📋  Başvurular"),
    ("cv", "📄  CV'lerim"),
    ("accounts", "🔐  Hesaplar"),
    ("settings", "⚙️  Ayarlar"),
    ("sites", "🌐  Siteler"),
    ("jobs", "🔍  Onay Kuyruğu"),
]

KVKK_TEXT = (
    "KVKK Aydınlatma Metni ve Kullanım Koşulları\n\n"
    "1. VERİ İŞLEME: Aerise tüm verilerini (CV, kimlik bilgileri, başvuru geçmişi) "
    "yalnızca SENİN BİLGİSAYARINDA saklar. Hiçbir veri sunucuya gönderilmez.\n\n"
    "2. KİMLİK BİLGİLERİ: Site şifreleri, Windows Kimlik Bilgisi Yöneticisi (keyring) "
    "ile şifreli olarak saklanır; uygulama içinde düz metin olarak tutulmaz.\n\n"
    "3. OTOMATİK BAŞVURU: Uygulama senin adına, senin hesaplarınla başvuru yapar. "
    "İş sitelerinin kullanım şartları otomasyonu kısıtlayabilir; hesabınla ilgili "
    "doğabilecek riskler sana aittir. Onay Kuyruğu modu ile her başvuruyu "
    "gönderilmeden önce kontrol edebilirsin.\n\n"
    "4. GÜVENLİK: CAPTCHA veya güvenlik doğrulaması ile karşılaşıldığında otomasyon "
    "DURUR ve senin çözmeni bekler; hiçbir güvenlik önlemi atlatılmaz.\n\n"
    "5. SİLME HAKKI: 'Ayarlar > Verilerimi Sil' ile tüm yerel verini anında silebilirsin."
)


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} — Akıllı İş Başvuru Asistanı v{APP_VERSION}")
        self.geometry("1180x720")
        self.minsize(1000, 640)
        if os.path.exists(ICON_PATH):
            try:
                self.iconbitmap(ICON_PATH)
            except Exception:
                pass
        self.settings = load_settings()
        engine.add_listener(self._log)
        engine.add_status_listener(self._on_status_update)
        self._cv_rows = {}
        self._site_status_lbls = {}
        self._selected_urls = set()   # Onay Kuyrugu'nda coklu secim
        self._row_map = {}            # url -> {chk, status_lbl}
        self._job_by_url = {}
        self._last_shown = 0

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()

        self.frames = {}
        for key, builder in [
            ("dashboard", self._build_dashboard),
            ("approval", self._build_approval),
            ("cv", self._build_cv_tab),
            ("accounts", self._build_accounts),
            ("settings", self._build_settings),
            ("sites", self._build_sites),
            ("jobs", self._build_jobs),
        ]:
            f = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
            f.grid(row=0, column=1, sticky="nsew", padx=24, pady=24)
            builder(f)
            self.frames[key] = f
        self.show("dashboard")
        if not engine.kvkk_accepted:
            self.after(400, self._show_kvkk)

    # ================= sidebar =================

    def _build_sidebar(self):
        sb = ctk.CTkFrame(self, width=240, corner_radius=0)
        sb.grid(row=0, column=0, sticky="nsw")
        sb.grid_propagate(False)
        if os.path.exists(LOGO_PATH):
            try:
                from PIL import Image
                logo = ctk.CTkImage(Image.open(LOGO_PATH), size=(96, 96))
                ctk.CTkLabel(sb, image=logo, text="").pack(pady=(24, 4))
            except Exception:
                pass
        ctk.CTkLabel(sb, text=APP_NAME, font=("Segoe UI Semibold", 28), anchor="w").pack(
            padx=24, pady=(2, 2))
        ctk.CTkLabel(sb, text="Akıllı İş Başvuru Asistanı", font=FONT_SM,
                     text_color="gray60", anchor="w").pack(padx=24, pady=(0, 22))
        self._nav_btns = {}
        for key, label in NAV_ITEMS:
            b = ctk.CTkButton(sb, text=label, font=FONT_SUB, anchor="w", height=40,
                              corner_radius=8, fg_color="transparent",
                              text_color=("gray10", "gray80"),
                              hover_color=("gray80", "#2a2f3d"),
                              command=lambda k=key: self.show(k))
            b.pack(fill="x", padx=14, pady=2)
            self._nav_btns[key] = b
        # alt kısım: güncelleme + log temizleme
        ctk.CTkButton(sb, text="🔄  Güncellemeleri Kontrol Et", height=32,
                      fg_color="transparent", border_width=1, border_color="gray40",
                      font=("Segoe UI", 11), command=self._check_updates).pack(
            fill="x", padx=14, pady=(0, 6))
        ctk.CTkButton(sb, text="🧹  Logları Temizle", height=32,
                      fg_color="transparent", border_width=1, border_color="gray40",
                      font=("Segoe UI", 11), command=self._clear_logs).pack(
            fill="x", padx=14, pady=(0, 6))
        ctk.CTkLabel(sb, text=f"v{APP_VERSION} · KVKK uyumlu · 100% lokal",
                     font=("Segoe UI", 10), text_color="gray50").pack(side="bottom", pady=12)

    def show(self, key):
        for k, f in self.frames.items():
            f.grid_remove()
        self.frames[key].grid()
        for k, b in self._nav_btns.items():
            if k == key:
                b.configure(fg_color=ACCENT, text_color="white")
            else:
                b.configure(fg_color="transparent", text_color=("gray10", "gray80"))
        if key == "jobs":
            self._refresh_jobs()
        if key == "approval":
            self._refresh_approval()

    # ================= helpers =================

    def _card(self, parent, title=""):
        card = ctk.CTkFrame(parent, corner_radius=12, fg_color=BG_CARD)
        if title:
            ctk.CTkLabel(card, text=title, font=FONT_SUB, anchor="w").pack(
                fill="x", padx=18, pady=(14, 4))
        card._body = ctk.CTkFrame(card, fg_color="transparent")
        card._body.pack(fill="both", expand=True)
        return card

    def _page_header(self, f, title, subtitle=""):
        ctk.CTkLabel(f, text=title, font=FONT_H, anchor="w").pack(fill="x", pady=(0, 4))
        if subtitle:
            ctk.CTkLabel(f, text=subtitle, font=FONT_SM, text_color="gray60",
                         anchor="w", wraplength=800, justify="left").pack(fill="x", pady=(0, 16))

    # ================= dashboard =================

    def _build_dashboard(self, f):
        f.grid_columnconfigure(0, weight=1)
        f.grid_columnconfigure(1, weight=1)
        f.grid_rowconfigure(3, weight=1)

        hero = self._card(f)
        hero.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 14))
        ctk.CTkLabel(hero._body, text="Kontrol Paneli", font=FONT_H, anchor="w").pack(
            fill="x", padx=18, pady=(16, 2))
        ctk.CTkLabel(hero._body, text="Aerise iş sitelerini tarar, CV'ine göre puanlar ve uygun ilanlara başvurur.",
                     font=FONT_SM, text_color="gray60", anchor="w").pack(fill="x", padx=18, pady=(0, 12))

        self.stat_today = self._stat_card(f, "Bugünkü Başvuru", str(db.todays_application_count()))
        self.stat_today.grid(row=1, column=0, sticky="ew", padx=(0, 7))
        self.stat_total = self._stat_card(f, "Takipteki İlan", str(len(db.all_jobs())))
        self.stat_total.grid(row=1, column=1, sticky="ew", padx=(7, 0))

        ctrl = self._card(f, "Otomasyon")
        ctrl.grid(row=2, column=0, columnspan=2, sticky="ew", pady=14)
        row = ctk.CTkFrame(ctrl._body, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=10)
        self.btn_browser = ctk.CTkButton(row, text="🌐  Tarayıcıyı Aç (Tüm Siteler)", height=44,
                                         font=FONT_SUB, command=self._open_browser)
        self.btn_browser.pack(side="left", padx=(0, 10))
        self.btn_start = ctk.CTkButton(row, text="▶  Başlat", height=44, font=FONT_SUB,
                                       fg_color=GREEN, hover_color="#15803d", command=self._start)
        self.btn_start.pack(side="left", padx=(0, 10))
        self.btn_stop = ctk.CTkButton(row, text="⏸  Durdur", height=44, font=FONT_SUB,
                                      fg_color=RED, hover_color="#b91c1c",
                                      state="disabled", command=self._stop)
        self.btn_stop.pack(side="left")

        self.status_lbl = ctk.CTkLabel(ctrl._body, text="● Hazır — önce tarayıcıyı açıp sitelere giriş yap.",
                                       font=FONT_SUB, text_color="gray55", anchor="w")
        self.status_lbl.pack(fill="x", padx=18, pady=(0, 12))

        logcard = self._card(f, "Canlı Log")
        logcard.grid(row=3, column=0, columnspan=2, sticky="nsew")
        self.log_box = ctk.CTkTextbox(logcard._body, font=("Consolas", 12), wrap="word")
        self.log_box.pack(fill="both", expand=True, padx=14, pady=(4, 14))

    def _stat_card(self, parent, title, value):
        c = self._card(parent)
        ctk.CTkLabel(c._body, text=title, font=FONT_SM, text_color="gray60", anchor="w").pack(
            fill="x", padx=18, pady=(14, 0))
        lbl = ctk.CTkLabel(c._body, text=value, font=("Segoe UI Semibold", 34), anchor="w")
        lbl.pack(fill="x", padx=18, pady=(0, 14))
        c._value_lbl = lbl
        return c

    # ================= approval queue =================

    def _build_approval(self, f):
        self._page_header(f, "Başvurular — Elle Başvuru Takibi",
                          "Onay Kuyruğu sekmesinden '📤 Başvurulara Al' ile eklediğin ilanlar burada bekler. "
                          "İlanı aç, sitede elle başvurunu yap, sonra '✅ Başvurdum' ile işaretle — "
                          "tamamlananlar aşağıdaki bölüme düşer ve kayıt olur.")
        self.approval_list = ctk.CTkScrollableFrame(f, fg_color="transparent")
        self.approval_list.pack(fill="both", expand=True)

    def _approval_row(self, parent, j, completed=False):
        row = ctk.CTkFrame(parent, fg_color=BG_CARD, corner_radius=10)
        row.pack(fill="x", pady=4)
        info = ctk.CTkFrame(row, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True, padx=(16, 8), pady=10)
        ctk.CTkLabel(info, text=("✅ " if completed else "⏳ ") + (j.get("title") or "—"),
                     font=("Segoe UI Semibold", 14), anchor="w").pack(fill="x")
        when = (j.get("applied_at") or "")[:16]
        sub = f"{j.get('site')} · {j.get('company') or '—'} · skor {j.get('score') or 0:.0f}"
        if completed and when:
            sub += f" · başvuru: {when}"
        ctk.CTkLabel(info, text=sub, font=FONT_SM, text_color="gray60", anchor="w").pack(fill="x")
        if not completed:
            ctk.CTkButton(row, text="🌐  İlanı Aç", width=110, height=36,
                          command=lambda u=j.get("url"): self._open_url(u)).pack(side="left", padx=4, pady=10)
            ctk.CTkButton(row, text="✅  Başvurdum", width=130, height=36,
                          fg_color=GREEN, hover_color="#15803d",
                          command=lambda jj=j: self._mark_applied(jj)).pack(side="left", padx=4)
            ctk.CTkButton(row, text="✖", width=40, height=36, fg_color="#7f1d1d",
                          hover_color=RED,
                          command=lambda jj=j: self._unqueue(jj)).pack(side="left", padx=(4, 14))
        else:
            ctk.CTkButton(row, text="🌐", width=44, height=36,
                          command=lambda u=j.get("url"): self._open_url(u)).pack(side="left", padx=4, pady=10)
            ctk.CTkButton(row, text="↩", width=44, height=36, fg_color="#7f1d1d",
                          hover_color=RED,
                          command=lambda jj=j: self._unmark_applied(jj)).pack(side="left", padx=(4, 14))

    def _refresh_approval(self):
        for w in self.approval_list.winfo_children():
            w.destroy()
        allj = db.all_jobs()
        pending = [j for j in allj if j.get("status") == "onay_bekliyor"]
        done = [j for j in allj if j.get("status") == "applied"]
        pending.sort(key=lambda j: (j.get("score") or 0), reverse=True)
        done.sort(key=lambda j: (j.get("applied_at") or ""), reverse=True)

        ctk.CTkLabel(self.approval_list, text=f"⏳ Bekleyen başvurular ({len(pending)}):",
                     font=("Segoe UI Semibold", 14), anchor="w").pack(fill="x", pady=(0, 6))
        if not pending:
            ctk.CTkLabel(self.approval_list, text="Kuyrukta bekleyen yok. 🎉\n\nOnay Kuyruğu sekmesinde beğendiğin ilanın detayını açıp\n'📤 Başvurulara Al' ile buraya ekleyebilirsin.",
                         font=FONT_SM, text_color="gray55", justify="left").pack(fill="x", pady=(0, 16))
        for j in pending:
            self._approval_row(self.approval_list, j, completed=False)

        ctk.CTkLabel(self.approval_list, text=f"✅ Tamamlanan başvurular ({len(done)}):",
                     font=("Segoe UI Semibold", 14), anchor="w").pack(fill="x", pady=(18, 6))
        if not done:
            ctk.CTkLabel(self.approval_list, text="Henüz tamamlanan başvuru yok.",
                         font=FONT_SM, text_color="gray55", anchor="w").pack(fill="x")
        for j in done[:30]:
            self._approval_row(self.approval_list, j, completed=True)

    def _open_url(self, url):
        if url:
            import webbrowser
            webbrowser.open(url)

    def _mark_applied(self, j):
        db.update_status(j["url"], "applied", j.get("cv_profile") or "",
                         (j.get("notes") or "") + " | elle başvuruldu")
        self._log(f"[✅] Başvuruldu işaretlendi: {j.get('title')}")
        self._refresh_approval()

    def _unqueue(self, j):
        db.update_status(j["url"], "found", j.get("cv_profile") or "", "kuyruktan çıkarıldı")
        self._refresh_approval()

    # ================= CV tab =================

    def _build_cv_tab(self, f):
        self._page_header(f, "CV'lerim",
                          "Her profil bir CV'dir. Uygulama ilanın içeriğine göre en uygun profili otomatik seçer "
                          "ve o CV'yi yükler. Yeni profil ekleyebilir, gereksizleri silebilirsin.")
        addrow = ctk.CTkFrame(f, fg_color="transparent")
        addrow.pack(fill="x", pady=(0, 14))
        self.new_cv_name = ctk.CTkEntry(addrow, width=260, height=36,
                                        placeholder_text="Yeni profil adı (örn. Veri Analisti)")
        self.new_cv_name.pack(side="left", padx=(0, 10))
        ctk.CTkButton(addrow, text="＋  Yeni CV Profili Ekle", height=36, font=FONT_SUB,
                      command=self._add_profile).pack(side="left")
        self.cv_list = ctk.CTkFrame(f, fg_color="transparent")
        self.cv_list.pack(fill="both", expand=True)
        self._render_cv_list()

    def _render_cv_list(self):
        for w in self.cv_list.winfo_children():
            w.destroy()
        self._cv_rows = {}
        for name, cfg in self.settings.get("cv_profiles", {}).items():
            label = cfg.get("label", name)
            icon = "🛡️" if ("güven" in label or "siber" in label.lower()) else "🖥️"
            card = self._card(self.cv_list)
            card.pack(fill="x", pady=7)
            head = ctk.CTkFrame(card._body, fg_color="transparent")
            head.pack(fill="x", padx=18, pady=(12, 4))
            ctk.CTkLabel(head, text=f"{icon}  {label}", font=FONT_SUB).pack(side="left")
            ctk.CTkButton(head, text="🗑  Sil", width=80, height=30, fg_color="#7f1d1d",
                          hover_color=RED, font=("Segoe UI", 11),
                          command=lambda n=name: self._delete_profile(n)).pack(side="right")
            path_lbl = ctk.CTkLabel(card._body, text=self._short(cfg.get("path", "— CV seçilmedi")),
                                    font=("Consolas", 11), text_color="gray55", anchor="w")
            path_lbl.pack(fill="x", padx=18)
            ctk.CTkButton(card._body, text="📁  CV Dosyası Seç (.pdf)", width=190, height=36,
                          command=lambda n=name: self._pick_cv(n)).pack(anchor="e", padx=18, pady=(2, 12))
            self._cv_rows[name] = (path_lbl, label)

    def _short(self, p):
        return p if len(p) <= 70 else "…" + p[-69:]

    def _add_profile(self):
        name = (self.new_cv_name.get() or "").strip().lower().replace(" ", "_")
        if not name:
            mb.showwarning("Aerise", "Önce profil adı yaz.")
            return
        if name in self.settings["cv_profiles"]:
            mb.showwarning("Aerise", "Bu isimde profil zaten var.")
            return
        self.settings["cv_profiles"][name] = {
            "label": self.new_cv_name.get().strip(), "path": "",
            "for_keywords": [name.replace("_", " ")]}
        save_settings(self.settings)
        self.new_cv_name.delete(0, "end")
        self._render_cv_list()
        self._log(f"[✓] Yeni CV profili eklendi: {name}")

    def _delete_profile(self, name):
        if not mb.askyesno("Aerise", f"'{name}' profili silinsin mi? (CV dosyası da kaldırılır)"):
            return
        cfg = self.settings["cv_profiles"].pop(name, None)
        if cfg and cfg.get("path"):
            try:
                p = cfg["path"]
                full = p if os.path.isabs(p) else os.path.join(project_root(), p)
                if os.path.exists(full):
                    os.remove(full)
            except Exception:
                pass
        save_settings(self.settings)
        self._render_cv_list()
        self._log(f"[✓] Profil silindi: {name}")

    def _pick_cv(self, name):
        path = fd.askopenfilename(title="CV seç", filetypes=[("PDF dosyası", "*.pdf")])
        if not path:
            return
        dest_dir = os.path.join(project_root(), "cvs")
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, os.path.basename(path))
        shutil.copy(path, dest)
        self.settings["cv_profiles"][name]["path"] = os.path.relpath(dest, project_root())
        save_settings(self.settings)
        self._cv_rows[name][0].configure(text=self._short(self.settings["cv_profiles"][name]["path"]))
        self._log(f"[✓] CV kaydedildi: {name} ← {os.path.basename(path)}")

    # ================= accounts (keyring) =================

    def _build_accounts(self, f):
        self._page_header(f, "Hesaplar",
                          "Şifreler Windows Kimlik Bilgisi Yöneticisi'nde (keyring) şifreli saklanır. "
                          "Oturum düşerse Aileron otomatik yeniden giriş yapmayı dener; başarısız olursa "
                          "seni uyarır ve bekler.")
        self.acc_vars = {}
        scroll = ctk.CTkScrollableFrame(f, fg_color="transparent")
        scroll.pack(fill="both", expand=True)
        for i, site in enumerate(SITE_REGISTRY.keys()):
            row = ctk.CTkFrame(scroll, fg_color=BG_CARD, corner_radius=10)
            row.pack(fill="x", pady=4)
            ctk.CTkLabel(row, text=site, font=FONT_SUB, width=160, anchor="w").pack(
                side="left", padx=(16, 8), pady=10)
            email = ctk.CTkEntry(row, width=230, height=32, placeholder_text="e-posta")
            email.pack(side="left", padx=4)
            pw = ctk.CTkEntry(row, width=180, height=32, placeholder_text="şifre", show="•")
            pw.pack(side="left", padx=4)
            existing = engine.get_credential(site)
            if existing:
                email.insert(0, existing[0])
            ctk.CTkButton(row, text="💾", width=40, height=32,
                          command=lambda s=site, e=email, p=pw: self._save_cred(s, e, p)).pack(
                side="left", padx=4)
            ctk.CTkButton(row, text="🗑", width=40, height=32, fg_color="#7f1d1d",
                          hover_color=RED,
                          command=lambda s=site, e=email, p=pw: self._del_cred(s, e, p)).pack(
                side="left", padx=(0, 12))
            self.acc_vars[site] = (email, pw)

    def _save_cred(self, site, email_entry, pw_entry):
        email, pw = email_entry.get().strip(), pw_entry.get().strip()
        if not email or not pw:
            mb.showwarning("Aerise", "E-posta ve şifre gir.")
            return
        engine.set_credential(site, email, pw)
        pw_entry.delete(0, "end")

    def _del_cred(self, site, email_entry, pw_entry):
        engine.delete_credential(site)
        email_entry.delete(0, "end")
        pw_entry.delete(0, "end")
        self._log(f"[🔐] {site} kimlik bilgileri silindi.")

    # ================= settings =================

    def _build_settings(self, f):
        self._page_header(f, "Ayarlar")
        p = self.settings.get("personal", {})
        self.vars = {}
        fields = [("full_name", "Ad Soyad"), ("email", "E-posta"), ("phone", "Telefon"),
                  ("city", "Şehir"), ("linkedin", "LinkedIn (opsiyonel)")]
        grid = ctk.CTkFrame(f, fg_color="transparent")
        grid.pack(fill="x")
        for i, (key, label) in enumerate(fields):
            ctk.CTkLabel(grid, text=label, font=FONT_SM, anchor="w").grid(
                row=i, column=0, sticky="w", padx=(4, 14), pady=6)
            v = ctk.StringVar(value=str(p.get(key, "")))
            self.vars[key] = v
            ctk.CTkEntry(grid, width=380, textvariable=v, height=36).grid(
                row=i, column=1, sticky="w", pady=6)
        ctk.CTkLabel(grid, text="Varsayılan Ön Yazı", font=FONT_SM, anchor="w").grid(
            row=len(fields), column=0, sticky="nw", padx=(4, 14), pady=6)
        self.cover_text = ctk.CTkTextbox(grid, width=380, height=88)
        self.cover_text.insert("1.0", p.get("cover_letter", ""))
        self.cover_text.grid(row=len(fields), column=1, sticky="w", pady=6)

        card = self._card(f, "Arama ve Otomasyon")
        card.pack(fill="x", pady=(16, 8))
        s = self.settings.get("search", {})
        self.search_vars = {}
        # sehir ve anahtar kelime kontrolü (grid ile — pack/grid karisimini onler)
        ctk.CTkLabel(card._body, text="Şehirler (virgülle ayır):", font=FONT_SM,
                     anchor="w").grid(row=0, column=0, sticky="w", padx=(18, 14), pady=6)
        self.cities_var = ctk.StringVar(value=", ".join(s.get("cities", [])))
        ctk.CTkEntry(card._body, width=380, textvariable=self.cities_var, height=32,
                     placeholder_text="Örn: Ankara, İstanbul, İzmir, Uzaktan").grid(
            row=0, column=1, sticky="w", pady=6)
        ctk.CTkLabel(card._body, text="Pozisyon kelimeleri (virgülle):", font=FONT_SM,
                     anchor="w").grid(row=1, column=0, sticky="w", padx=(18, 14), pady=6)
        self.kw_var = ctk.StringVar(value=", ".join(s.get("keywords", [])))
        ctk.CTkEntry(card._body, width=380, textvariable=self.kw_var, height=32,
                     placeholder_text="Örn: BT Destek, Siber Güvenlik, SOC").grid(
            row=1, column=1, sticky="w", pady=6)
        rows = [("min_match_score", "Minimum uygunluk skoru (0-100)", s.get("min_match_score", 55)),
                ("max_applications_per_day", "Günlük maksimum başvuru", s.get("max_applications_per_day", 12))]
        for i, (key, label, val) in enumerate(rows):
            ctk.CTkLabel(card._body, text=label, font=FONT_SM, anchor="w").grid(
                row=i + 2, column=0, sticky="w", padx=(18, 14), pady=6)
            v = ctk.StringVar(value=str(val))
            self.search_vars[key] = v
            ctk.CTkEntry(card._body, width=90, textvariable=v, height=32).grid(
                row=i + 2, column=1, sticky="w", pady=6)
        self.approval_var = ctk.BooleanVar(value=bool(self.settings.get("approval_mode", True)))
        ctk.CTkCheckBox(card._body, text="Onay kuyruğu modu (her başvuru gönderilmeden önce bana sorulsun)",
                        variable=self.approval_var, font=FONT_SM).grid(
            row=4, column=0, columnspan=2, sticky="w", padx=18, pady=8)
        self.disabled_var = ctk.BooleanVar(value=bool(self.settings.get("apply_disabled_jobs", False)))
        ctk.CTkCheckBox(card._body, text="Engelli (kota) ilanlarına da başvur",
                        variable=self.disabled_var, font=FONT_SM).grid(
            row=5, column=0, columnspan=2, sticky="w", padx=18, pady=8)
        self.auto_apply_var = ctk.BooleanVar(value=bool(self.settings.get("auto_apply", False)))
        ctk.CTkCheckBox(card._body, text="Otomatik başvuru (DENEYSEL — form doldurma siteye göre değişir;\n      kapalıysa sistem sadece tarar ve listeler, elle başvurursun)",
                        variable=self.auto_apply_var, font=FONT_SM).grid(
            row=6, column=0, columnspan=2, sticky="w", padx=18, pady=8)

        row = ctk.CTkFrame(f, fg_color="transparent")
        row.pack(fill="x", pady=(14, 0))
        ctk.CTkButton(row, text="💾  Kaydet", height=40, width=150, font=FONT_SUB,
                      command=self._save_settings).pack(side="left", padx=(0, 10))
        ctk.CTkButton(row, text="🗑  Verilerimi Sil (KVKK)", height=40, width=200, font=FONT_SUB,
                      fg_color="#7f1d1d", hover_color=RED,
                      command=self._wipe_data).pack(side="left")

    def _save_settings(self):
        self.settings.setdefault("personal", {})
        for key, var in self.vars.items():
            self.settings["personal"][key] = var.get()
        self.settings["personal"]["cover_letter"] = self.cover_text.get("1.0", "end").strip()
        for key, var in self.search_vars.items():
            try:
                self.settings["search"][key] = float(var.get()) if key == "min_match_score" else int(var.get())
            except ValueError:
                pass
        # sehirler + anahtar kelimeler
        cities = [c.strip() for c in (self.cities_var.get() or "").split(",") if c.strip()]
        kws = [k.strip() for k in (self.kw_var.get() or "").split(",") if k.strip()]
        if cities:
            self.settings["search"]["cities"] = cities
        if kws:
            self.settings["search"]["keywords"] = kws
        self.settings["approval_mode"] = bool(self.approval_var.get())
        self.settings["apply_disabled_jobs"] = bool(self.disabled_var.get())
        self.settings["auto_apply"] = bool(self.auto_apply_var.get())
        save_settings(self.settings)
        self._log("[✓] Ayarlar kaydedildi.")

    def _wipe_data(self):
        if mb.askyesno("Aerise", "Tüm yerel veri silinecek:\n\n• Tarayıcı oturumları\n• Loglar\n• İlan veritabanı\n\nOnaylıyor musun?"):
            threading.Thread(target=self._wipe_worker, daemon=True).start()

    def _wipe_worker(self):
        engine.reset_profile_data()
        self.after(0, lambda: mb.showinfo("Aerise", "Tüm yerel veri silindi."))

    # ================= sites =================

    def _build_sites(self, f):
        self._page_header(f, "Siteler",
                          "Taramada kullanılacak iş sitelerini seç. LinkedIn misafir modunda çalışır; "
                          "tarayıcıda oturum açtıysan daha iyi sonuç verir.")
        enabled = set(self.settings.get("enabled_sites", list(SITE_REGISTRY.keys())))
        self.site_vars = {}
        self._site_status_lbls = {}

        btnrow = ctk.CTkFrame(f, fg_color="transparent")
        btnrow.pack(fill="x", pady=(0, 10))
        ctk.CTkButton(btnrow, text="🔄  Bağlantı Durumunu Kontrol Et", height=38, font=FONT_SUB,
                      command=lambda: engine.check_site_status()).pack(side="left")
        ctk.CTkLabel(btnrow, text="✅ girişli   ❌ giriş yok   ❓ belirsiz",
                     font=FONT_SM, text_color="gray55").pack(side="left", padx=14)

        grid = ctk.CTkScrollableFrame(f, fg_color="transparent")
        grid.pack(fill="both", expand=True)
        for i, site in enumerate(SITE_REGISTRY.keys()):
            row = ctk.CTkFrame(grid, fg_color=BG_CARD, corner_radius=10)
            row.grid(row=i // 2, column=i % 2, sticky="ew", padx=6, pady=5)
            v = ctk.BooleanVar(value=site in enabled)
            self.site_vars[site] = v
            ctk.CTkCheckBox(row, text=site, variable=v, font=FONT_SUB, checkbox_height=22,
                            checkbox_width=22).pack(side="left", padx=(14, 8), pady=12)
            status_lbl = ctk.CTkLabel(row, text="—", width=130, font=FONT_SM,
                                      anchor="e", text_color="gray55")
            status_lbl.pack(side="right", padx=(8, 14))
            self._site_status_lbls[site] = status_lbl
        self._render_site_status(engine.site_status)
        ctk.CTkButton(f, text="💾  Kaydet", height=40, width=150, font=FONT_SUB,
                      command=self._save_sites).pack(anchor="w", pady=(14, 0))

    def _render_site_status(self, status: dict):
        marks = {"logged_in": ("✅ Girişli", "#22c55e"),
                 "logged_out": ("❌ Giriş yok", "#ef4444"),
                 "unknown": ("❓ Belirsiz", "gray55")}
        for site, lbl in self._site_status_lbls.items():
            state = status.get(site, "")
            if state in marks:
                text, color = marks[state]
                lbl.configure(text=text, text_color=color)
            else:
                lbl.configure(text="—", text_color="gray55")

    def _on_status_update(self, status: dict):
        def update():
            self._render_site_status(status)
            if "sites" in self.frames and self.frames["sites"].winfo_viewable():
                pass
        try:
            self.after(0, update)
        except Exception:
            pass

    def _save_sites(self):
        self.settings["enabled_sites"] = [s for s, v in self.site_vars.items() if v.get()]
        save_settings(self.settings)
        self._log(f"[✓] Siteler kaydedildi ({len(self.settings['enabled_sites'])} adet aktif).")

    # ================= jobs =================

    STATUS_LABELS = {
        "applied": ("✅ Başvuruldu", "#22c55e"),
        "onay_bekliyor": ("⏸ Onay bekliyor", "#3b82f6"),
        "found": ("• Bulundu", "gray65"),
        "needs_attention": ("⚠ Elle bakılmalı", "#f59e0b"),
        "failed": ("✖ Hata", "#ef4444"),
        "rejected": ("– Reddedildi", "#9ca3af"),
    }

    def _build_jobs(self, f):
        self._page_header(f, "Onay Kuyruğu — Bulunan İlanlar",
                          "Sistemin bulduğu tüm ilanlar (skora göre sıralı). Beğendiğin ilanın detayını açıp "
                          "'📤 Başvurulara Al' ile Başvurular sekmesine ekleyebilirsin; oradan elle başvurup takip edersin.")
        # filtre satırı
        frow = ctk.CTkFrame(f, fg_color="transparent")
        frow.pack(fill="x", pady=(0, 8))
        self.job_filter = ctk.CTkOptionMenu(frow, values=["🚀 İşlem Görenler", "Tümü", "✅ Başvuruldu",
                                                          "⏸ Onay bekliyor", "⚠ Elle bakılmalı",
                                                          "✖ Hata", "– Reddedildi", "• Bulundu"],
                                            width=190, height=32, font=FONT_SM,
                                            command=lambda _=None: self._refresh_jobs())
        self.job_filter.set("🚀 İşlem Görenler")
        self.job_filter.pack(side="left")
        ctk.CTkButton(frow, text="🗑  Bu Kategoriyi Temizle", width=180, height=32,
                      fg_color="#7f1d1d", hover_color=RED, font=FONT_SM,
                      command=self._purge_category).pack(side="left", padx=(0, 8))
        self.job_search = ctk.CTkEntry(frow, width=240, height=32, placeholder_text="🔍 pozisyon/firma ara...")
        self.job_search.pack(side="left", padx=8)
        self.job_search.bind("<KeyRelease>", lambda e: self._refresh_jobs())
        self.job_count_lbl = ctk.CTkLabel(frow, text="", font=FONT_SM, text_color="gray55")
        self.job_count_lbl.pack(side="left", padx=8)

        self.tree = ctk.CTkScrollableFrame(f, orientation="vertical")
        self.tree.pack(fill="both", expand=True)
        self._header = ctk.CTkFrame(self.tree, fg_color="transparent")
        self._header.pack(fill="x", pady=(0, 4))
        for col, (text, w) in enumerate([("✓", 30), ("DURUM", 140), ("POZİSYON", 300), ("FİRMA", 140),
                                         ("SKOR", 55), ("TARİH", 140), ("", 40)]):
            ctk.CTkLabel(self._header, text=text, font=("Segoe UI Semibold", 12),
                         width=w, anchor="w").grid(row=0, column=col)
        self._rows_frame = ctk.CTkFrame(self.tree, fg_color="transparent")
        self._rows_frame.pack(fill="x")

        # detay paneli
        self.detail = self._card(f, "İlan Detayı")
        self.detail.pack(fill="x", pady=(10, 0))
        self.detail_body = ctk.CTkLabel(self.detail._body, text="Bir ilan seç...",
                                        font=FONT_SM, justify="left", anchor="w", wraplength=820)
        self.detail_body.pack(fill="x", padx=18, pady=(4, 8))
        dbtn = ctk.CTkFrame(self.detail._body, fg_color="transparent")
        dbtn.pack(fill="x", padx=18, pady=(0, 12))
        self.btn_open_job = ctk.CTkButton(dbtn, text="🌐  İlan Sayfasını Aç", height=34, width=180,
                                          state="disabled", command=self._open_job_url)
        self.btn_open_job.pack(side="left", padx=(0, 8))
        self.btn_queue = ctk.CTkButton(dbtn, text="📤  Başvurulara Al", height=34, width=180,
                                       state="disabled", command=self._queue_selected)
        self.btn_queue.pack(side="left", padx=(0, 8))
        self.btn_mark = ctk.CTkButton(dbtn, text="✅  Başvuruldu İşaretle", height=34, width=180,
                                      state="disabled", fg_color=GREEN, hover_color="#15803d",
                                      command=self._mark_selected_applied)
        self.btn_mark.pack(side="left")
        self._selected_job = None

        # coklu secim eylem cubugu
        selrow = ctk.CTkFrame(f, fg_color="transparent")
        selrow.pack(fill="x", pady=(8, 0))
        self.btn_send_selected = ctk.CTkButton(selrow, text="📤  Seçilenleri Başvurulara Gönder (0)",
                                               height=40, font=FONT_SUB, state="disabled",
                                               command=self._send_selected)
        self.btn_send_selected.pack(side="left", padx=(0, 8))
        ctk.CTkButton(selrow, text="↩ Seçimi Temizle", height=40, width=150, font=FONT_SUB,
                      fg_color="transparent", border_width=1, border_color="gray40",
                      command=self._clear_selection).pack(side="left")
        ctk.CTkLabel(selrow, text="Kutucuklar sadece SEÇİM içindir — işaretlemek başvuru yapmaz;\n"
                                 "seçtiklerinden sonra alttaki butonla toplu gönder.",
                     font=("Segoe UI", 11), text_color="gray55", anchor="w", justify="left").pack(side="left", padx=14)

    def _toggle_select(self, j):
        """Kutucuk = sadece seçim (db degismez, liste yeniden kurulmaz → donma yok)."""
        if j["url"] in self._selected_urls:
            self._selected_urls.discard(j["url"])
        else:
            self._selected_urls.add(j["url"])
        self._update_sel_button()

    def _update_sel_button(self):
        n = len(self._selected_urls)
        self.btn_send_selected.configure(
            text=f"📤  Seçilenleri Başvurulara Gönder ({n})",
            state="normal" if n else "disabled")

    def _clear_selection(self):
        self._selected_urls.clear()
        self._update_sel_button()
        self._refresh_jobs()

    def _send_selected(self):
        n = 0
        for url in list(self._selected_urls):
            j = self._job_by_url.get(url)
            if j and j.get("status") in ("found", "needs_attention"):
                self._set_status_inplace(j, "onay_bekliyor", " | toplu seçim")
                n += 1
        self._selected_urls.clear()
        self._update_sel_button()
        self._log(f"[📤] {n} ilan Başvurular listesine alındı.")
        self._refresh_jobs()

    def _set_status_inplace(self, j, new_status, note_suffix=""):
        """DB güncelle + satırı yerinde güncelle (tüm listeyi yeniden kurmadan)."""
        db.update_status(j["url"], new_status, j.get("cv_profile") or "",
                         (j.get("notes") or "") + note_suffix)
        j["status"] = new_status
        info = self._row_map.get(j["url"])
        if info:
            text, color = self.STATUS_LABELS.get(new_status, (new_status, "gray70"))
            info["status_lbl"].configure(text=text, text_color=color)
            if new_status == "applied":
                info["chk"].select()
            else:
                info["chk"].deselect()
        self._update_counts()

    def _update_counts(self):
        counts = {}
        for j in self._job_by_url.values():
            counts[j.get("status")] = counts.get(j.get("status"), 0) + 1
        self.job_count_lbl.configure(
            text=f"{self._last_shown} gösteriliyor / {len(self._job_by_url)} ilan | " +
                 " ".join(f"{self.STATUS_LABELS.get(s, (s,))[0]}: {n}" for s, n in counts.items()))

    def _queue_selected(self):
        j = self._selected_job
        if not j:
            return
        db.update_status(j["url"], "onay_bekliyor", j.get("cv_profile") or "",
                         (j.get("notes") or "") + " | elle kuyruğa alındı")
        self._log(f"[📤] Başvurular listesine alındı: {j.get('title')} — Başvurular sekmesinden takip et.")
        self._refresh_jobs()

    def _mark_selected_applied(self):
        j = self._selected_job
        if not j:
            return
        self._set_status_inplace(j, "applied", " | elle başvuruldu")
        self._log(f"[✅] Başvuruldu işaretlendi: {j.get('title')}")

    def _open_job_url(self):
        if self._selected_job and self._selected_job.get("url"):
            import webbrowser
            webbrowser.open(self._selected_job["url"])

    def _refresh_jobs(self):
        for w in self._rows_frame.winfo_children():
            w.destroy()
        filt = self.job_filter.get()
        codes = {"✅ Başvuruldu": {"applied"}, "⏸ Onay bekliyor": {"onay_bekliyor"},
                 "• Bulundu": {"found"}, "⚠ Elle bakılmalı": {"needs_attention"},
                 "✖ Hata": {"failed"}, "– Reddedildi": {"rejected"}}.get(filt)
        if filt == "🚀 İşlem Görenler":
            codes = {"applied", "onay_bekliyor", "needs_attention", "failed", "rejected"}
        q = (self.job_search.get() or "").lower()
        jobs = db.all_jobs()
        jobs.sort(key=lambda j: (j.get("score") or 0), reverse=True)  # puana göre sırala
        self._job_by_url = {j["url"]: j for j in jobs}
        self._row_map = {}
        shown = 0
        counts = {}
        for j in jobs:
            counts[j.get("status")] = counts.get(j.get("status"), 0) + 1
        for j in jobs:
            st = j.get("status") or "found"
            if codes and st not in codes:
                continue
            hay = f"{j.get('title','')} {j.get('company','')}".lower()
            if q and q not in hay:
                continue
            shown += 1
            if shown > 250:
                break
            text, color = self.STATUS_LABELS.get(st, (st, "gray70"))
            row = ctk.CTkFrame(self._rows_frame, fg_color="transparent")
            row.pack(fill="x", pady=1)
            vals = [(text, 150, color), (j.get("title") or "", 320, None),
                    (j.get("company") or "—", 150, None),
                    (f"{j.get('score') or 0:.0f}", 55, None),
                    ((j.get("applied_at") or "")[:16], 140, None)]
            chk = ctk.CTkCheckBox(row, text="", width=28, checkbox_width=20, checkbox_height=20,
                                  variable=ctk.BooleanVar(value=(j["url"] in self._selected_urls)),
                                  command=lambda jj=j: self._toggle_select(jj))
            chk.grid(row=0, column=0, padx=(12, 0))
            status_lbl = None
            for col, (val, w, c) in enumerate(vals):
                lbl = ctk.CTkLabel(row, text=str(val)[:38], font=("Segoe UI", 12), width=w,
                                   anchor="w", text_color=c)
                lbl.grid(row=0, column=col + 1)
                if col == 0:
                    status_lbl = lbl
            ctk.CTkButton(row, text="🔍", width=34, height=26, font=("Segoe UI", 11),
                          command=lambda jj=j: self._show_job_detail(jj)).grid(row=0, column=6)
            self._row_map[j["url"]] = {"chk": chk, "status_lbl": status_lbl}
        total = len(jobs)
        self._last_shown = shown
        self.job_count_lbl.configure(
            text=f"{shown} gösteriliyor / {total} ilan | " +
                 " ".join(f"{self.STATUS_LABELS.get(s, (s,))[0]}: {n}" for s, n in counts.items()))

    def _toggle_applied(self, j):
        """Başvurular sekmesindeki ↩: applied ↔ önceki durum. Liste yeniden kurulmaz."""
        st = j.get("status") or "found"
        if st == "applied":
            restore = "onay_bekliyor" if "kuyruğa alındı" in (j.get("notes") or "") else "found"
            self._set_status_inplace(j, restore, " | işaret geri alındı")
            self._log(f"[↩] Geri alındı: {j.get('title')}")
        else:
            self._set_status_inplace(j, "applied", " | elle başvuruldu")
            self._log(f"[✅] Başvuruldu işaretlendi: {j.get('title')}")

    def _unmark_applied(self, j):
        """Başvurular sekmesindeki ↩ butonu: durumu değiştir + kartı taşı."""
        self._toggle_applied(j)
        self._refresh_approval()

    def _purge_category(self):
        filt = self.job_filter.get()
        codes = {"✅ Başvuruldu": {"applied"}, "⏸ Onay bekliyor": {"onay_bekliyor"},
                 "• Bulundu": {"found"}, "⚠ Elle bakılmalı": {"needs_attention"},
                 "✖ Hata": {"failed"}, "– Reddedildi": {"rejected"}}.get(filt)
        if filt == "🚀 İşlem Görenler":
            mb.showwarning("Aileron", "İşlem gören başvurular silinemez — listeyi hafifletmek için\n'• Bulundu' kategorisini seç.")
            return
        if not codes:
            return
        cat = list(codes)[0]
        label = self.STATUS_LABELS.get(cat, (cat,))[0]
        if not mb.askyesno("Aileron", f"'{label}' durumundaki TÜM ilanlar listeden silinecek.\nDevam edilsin mi?"):
            return
        n = db.delete_by_status(cat)
        self._log(f"[🗑] {label}: {n} ilan temizlendi.")
        self._refresh_jobs()

    def _show_job_detail(self, j):
        self._selected_job = j
        text, color = self.STATUS_LABELS.get(j.get("status") or "found", ((j.get("status") or "found"), "gray70"))
        lines = (
            f"Pozisyon : {j.get('title') or '—'}\n"
            f"Firma    : {j.get('company') or '—'}   |   Site: {j.get('site')}   |   Konum: {j.get('location') or '—'}\n"
            f"Durum    : {text}   |   Uygunluk skoru: {j.get('score') or 0:.0f}\n"
            f"Gönderilen CV: {j.get('cv_profile') or '—'}   |   Tarih: {j.get('applied_at') or '—'}\n"
            f"Not      : {j.get('notes') or '—'}\n"
            f"Link     : {j.get('url') or '—'}")
        self.detail_body.configure(text=lines)
        st = j.get("status") or "found"
        self.btn_open_job.configure(state="normal")
        self.btn_mark.configure(state="normal")
        self.btn_queue.configure(state="normal" if st in ("found", "needs_attention") else "disabled")
        self.detail_body.configure(text_color=color if st == "applied" else "gray80")

    # ================= actions =================

    def _open_browser(self):
        self.btn_browser.configure(state="disabled")
        threading.Thread(target=self._launch_browser, daemon=True).start()

    def _launch_browser(self):
        try:
            engine.launch_browser()
            self.after(0, lambda: self.btn_browser.configure(state="normal"))
        except Exception as e:
            self._log(f"[x] Tarayıcı açılamadı: {e}")
            self.after(0, lambda: self.btn_browser.configure(state="normal"))

    def _start(self):
        if not engine.browser_open.is_set():
            self._log("[!] Önce 'Tarayıcıyı Aç' ile sitelere giriş yapmalısın.")
            return
        try:
            engine.start_automation()
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
            self.after(1500, self._watch_worker)
            self.status_lbl.configure(
                text="● Çalışıyor" + (" — onay kuyruğu modu aktif" if self.settings.get("approval_mode") else ""),
                text_color="#22c55e")
        except Exception as e:
            self._log(f"[x] Başlatılamadı: {e}")

    def _watch_worker(self):
        """Worker bitince Durdur butonunu normale döndür."""
        if not engine.is_running:
            self.btn_start.configure(state="normal")
            self.btn_stop.configure(state="disabled")
            self.status_lbl.configure(text="● Otomasyon döngüsü bitti.", text_color="#3b82f6")
        else:
            self.after(1500, self._watch_worker)

    def _stop(self):
        engine.stop_automation()
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.status_lbl.configure(text="● Durduruldu.", text_color="#f59e0b")

    def _check_updates(self):
        def worker():
            r = check_update(self.settings.get("update_url"))
            self._log(f"[🔄] Güncelleme: {r['message']}")
            if r["status"] == "available" and r.get("url"):
                self.after(0, lambda: mb.showinfo("Aerise Güncelleme",
                            f"{r['message']}\n\nİndirme: {r['url']}"))
        threading.Thread(target=worker, daemon=True).start()

    def _clear_logs(self):
        engine.clear_logs()
        self.log_box.delete("1.0", "end")

    def _log(self, msg):
        def append():
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.stat_total._value_lbl.configure(text=str(len(db.all_jobs())))
            self.stat_today._value_lbl.configure(text=str(db.todays_application_count()))
        try:
            self.after(0, append)
        except Exception:
            pass

    # ================= KVKK =================

    def _show_kvkk(self):
        win = ctk.CTkToplevel(self)
        win.title(f"{APP_NAME} — KVKK ve Kullanım")
        win.geometry("640x560")
        win.attributes("-topmost", True)
        box = ctk.CTkTextbox(win, font=("Segoe UI", 13), wrap="word")
        box.pack(fill="both", expand=True, padx=16, pady=(16, 8))
        box.insert("1.0", KVKK_TEXT)
        box.configure(state="disabled")
        var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(win, text="Okudum, anladım ve kabul ediyorum", variable=var,
                        font=FONT_SM).pack(anchor="w", padx=16, pady=6)

        def accept():
            if not var.get():
                mb.showwarning(APP_NAME, "Devam etmek için onay kutusunu işaretle.")
                return
            engine.accept_kvkk()
            win.destroy()

        ctk.CTkButton(win, text="Kabul Et ve Başla", height=42, font=FONT_SUB,
                      command=accept).pack(pady=(4, 16))


if __name__ == "__main__":
    db.init_db()
    App().mainloop()
