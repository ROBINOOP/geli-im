@echo off
rem İş Başvuru Otomasyonu başlatıcı
cd /d "%~dp0"
start "" pythonw main.py
