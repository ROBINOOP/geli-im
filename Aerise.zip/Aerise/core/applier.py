import os
import time
import random
from core.exceptions import NeedsHuman
from core.settings import project_root

# Field heuristics: input name/label/placeholder keywords -> value source in settings.personal
FIELD_MAP = {
    "first_name": ["ad", "isim", "first name", "firstname"],
    "last_name": ["soyad", "last name", "lastname", "surname"],
    "full_name": ["ad soyad", "tam ad", "full name", "name"],
    "email": ["e-posta", "eposta", "email", "mail"],
    "phone": ["telefon", "tel", "phone", "gsm", "cep"],
    "city": ["şehir", "sehir", "il", "city", "lokasyon", "konum"],
    "linkedin": ["linkedin"],
    "cover_letter": ["ön yazı", "on yazi", "neden", "cover", "motivasyon", "açıklama", "message"],
}

CAPTCHA_SELECTORS = [
    "iframe[src*='recaptcha']", "iframe[src*='hcaptcha']",
    "iframe[title*='reCAPTCHA']", "div[class*='captcha']", "div[id*='captcha']",
    "div[data-sitekey]", "span:has-text('güvenlik doğrulama')",
    "text=Güvenlik doğrulaması", "text=Verify you are human",
]

LOGIN_URL_HINTS = ["giris", "giriş", "login", "signin", "sign-in", "uyegirisi", "uye-girisi", "auth"]


class AutoApplier:
    def __init__(self, page, settings: dict, log_fn=print, creds_provider=None):
        self.page = page
        self.settings = settings
        self.log = log_fn
        self.creds_provider = creds_provider or (lambda site: None)

    # ---------- public ----------

    def apply(self, job: dict, profile, approval_mode: bool = False) -> str:
        """Tam otomatik başvuru. Dönüş: applied | filled_pending_approval |
        needs_attention | failed. CAPTCHA/giriş durumunda NeedsHuman fırlatır."""
        self._goto_job(job)
        self._ensure_logged_in(job)
        self._assert_no_captcha()

        if not self._click_apply_button():
            self.log(f"    [!] Başvur butonu bulunamadı: {job['url']}")
            return "needs_attention"
        time.sleep(random.uniform(2, 4))
        self._fill_form(profile)
        time.sleep(random.uniform(2, 4))

        self._assert_no_captcha()  # form sonrası tekrar kontrol
        if approval_mode:
            self.log("    [i] Form dolduruldu — onay kuyruğuna alındı (gönderilmedi).")
            return "filled_pending_approval"

        return self.submit()

    def submit(self) -> str:
        """Onay sonrası gönderim (onay kuyruğu modunda ayrı çağrılır)."""
        self._assert_no_captcha()
        if self._submit():
            self.log("    [✓] Başvuru gönderildi")
            return "applied"
        self.log("    [!] Gönderim butonu bulunamadı")
        return "needs_attention"

    # ---------- blockers ----------

    def _goto_job(self, job: dict):
        # dayanıklı navigasyon: ERR_ABORTED gibi geçici iptallere karşı
        last = None
        for attempt in range(3):
            try:
                self.page.goto(job["url"], wait_until="domcontentloaded", timeout=60000)
                break
            except Exception as e:
                last = e
                time.sleep(random.uniform(3, 6))
                try:
                    self.page.goto(job["url"], wait_until="commit", timeout=60000)
                    break
                except Exception:
                    continue
        else:
            raise last
        time.sleep(random.uniform(3, 6))

    def _assert_no_captcha(self):
        for sel in CAPTCHA_SELECTORS:
            try:
                el = self.page.query_selector(sel)
                if el and el.is_visible():
                    raise NeedsHuman("CAPTCHA/güvenlik doğrulaması algılandı — lütfen tarayıcıda elle çöz.")
            except NeedsHuman:
                raise
            except Exception:
                continue

    def _is_login_page(self) -> bool:
        url = (self.page.url or "").lower()
        if any(h in url for h in LOGIN_URL_HINTS):
            return True
        try:
            pw = self.page.query_selector("input[type='password']")
            return pw is not None and pw.is_visible()
        except Exception:
            return False

    def _ensure_logged_in(self, job: dict):
        """Giriş ekranındaysa: kayıtlı bilgilerle otomatik giriş dene,
        yoksa kullanıcıdan yardım iste (atlatma DENEMEZ)."""
        if not self._is_login_page():
            return
        site = job.get("site", "")
        creds = self.creds_provider(site)
        if creds:
            self.log(f"    [🔐] {site} oturumu düşmüş — kayıtlı bilgilerle yeniden giriliyor...")
            try:
                email_f = self.page.query_selector("input[type='email'], input[name*='mail'], input[name*='user']")
                pass_f = self.page.query_selector("input[type='password']")
                if email_f and pass_f:
                    email_f.fill(creds[0])
                    time.sleep(random.uniform(0.5, 1.5))
                    pass_f.type(creds[1], delay=random.randint(40, 90))
                    btn = self.page.query_selector("button[type='submit'], button:has-text('Giriş'), input[type='submit']")
                    if btn:
                        btn.click()
                        time.sleep(random.uniform(3, 6))
                        self._goto_job(job)
                        if not self._is_login_page():
                            self.log("    [✓] Yeniden giriş başarılı")
                            return
            except Exception as e:
                self.log(f"    [!] Otomatik giriş başarısız: {e}")
        raise NeedsHuman(f"{site} giriş ekranı açık — lütfen tarayıcıda elle giriş yap.")

    # ---------- form ----------

    def _click_apply_button(self) -> bool:
        candidates = [
            "button:has-text('Başvur')", "a:has-text('Başvur')",
            "button:has-text('Başvuru Yap')", "a:has-text('Başvuru Yap')",
            "button:has-text('Hemen Başvur')", "button:has-text('Apply')",
            "a:has-text('Apply')", "[data-testid='apply-button']",
            "#apply-button", ".apply-button",
        ]
        for sel in candidates:
            try:
                btn = self.page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.scroll_into_view_if_needed()
                    btn.click()
                    return True
            except Exception:
                continue
        return False

    def _fill_form(self, profile):
        p = self.settings.get("personal", {})
        inputs = self.page.query_selector_all(
            "input[type='text'], input[type='email'], input[type='tel'], "
            "input:not([type]), textarea")
        filled = 0
        for inp in inputs:
            try:
                if not inp.is_visible():
                    continue
                attrs = " ".join(filter(None, [
                    inp.get_attribute("name") or "", inp.get_attribute("id") or "",
                    inp.get_attribute("placeholder") or "", inp.get_attribute("aria-label") or "",
                ])).lower()
                hay = f"{attrs} {self._label_for(inp)}"
                value = self._value_for(hay, p)
                if value is None:
                    continue
                inp.click()
                inp.fill("")
                inp.type(str(value), delay=random.randint(30, 90))
                filled += 1
            except Exception:
                continue
        self.log(f"    [i] {filled} alan dolduruldu")
        self._upload_cv(profile)
        self._handle_dropdowns(p)

    def _label_for(self, input_el) -> str:
        try:
            fid = input_el.get_attribute("id")
            if fid:
                lab = self.page.query_selector(f"label[for='{fid}']")
                if lab:
                    return (lab.inner_text() or "").lower()
        except Exception:
            pass
        return ""

    def _value_for(self, hay: str, p: dict):
        hay = hay.lower()
        for field, keys in FIELD_MAP.items():
            if any(k in hay for k in keys):
                if field == "full_name":
                    return p.get("full_name")
                if field == "first_name":
                    return (p.get("full_name") or "").split(" ")[0]
                if field == "last_name":
                    parts = (p.get("full_name") or "").split(" ")
                    return parts[-1] if len(parts) > 1 else ""
                if field == "cover_letter":
                    return p.get("cover_letter")
                return p.get(field)
        return None

    def _upload_cv(self, profile):
        if not profile:
            return
        path = profile.pdf_path
        if not os.path.isabs(path):
            path = os.path.join(project_root(), path)
        if not os.path.exists(path):
            self.log(f"    [!] CV dosyası bulunamadı: {path}")
            return
        try:
            for fi in self.page.query_selector_all("input[type='file']"):
                if fi.is_visible():
                    fi.set_input_files(path)
                    self.log(f"    [i] CV yüklendi: {profile.name}")
                    time.sleep(random.uniform(1.5, 3))
                    return
        except Exception as e:
            self.log(f"    [!] CV yükleme hatası: {e}")

    def _handle_dropdowns(self, p: dict):
        try:
            for sel in self.page.query_selector_all("select"):
                label = self._label_for(sel).lower() + (sel.get_attribute("name") or "").lower()
                target = p.get("city") if any(k in label for k in ["şehir", "il", "city", "lokasyon"]) else None
                if not target:
                    continue
                for opt in sel.query_selector_all("option"):
                    if target.lower() in (opt.inner_text() or "").lower():
                        value = opt.get_attribute("value")
                        if value:
                            sel.select_option(value)
                        else:
                            sel.select_option(label=(opt.inner_text() or "").strip())
                        break
        except Exception:
            pass

    def _submit(self) -> bool:
        candidates = [
            "button:has-text('Başvuruyu Gönder')", "button:has-text('Gönder')",
            "button:has-text('Onayla ve Başvur')", "button[type='submit']",
            "input[type='submit']", "button:has-text('Submit')",
        ]
        for sel in candidates:
            try:
                btn = self.page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.scroll_into_view_if_needed()
                    time.sleep(random.uniform(1, 2.5))
                    btn.click()
                    time.sleep(random.uniform(3, 6))
                    return True
            except Exception:
                continue
        return False
