import threading
import random
import time
from datetime import datetime

from core.settings import load_settings
from core import db
from core.cv_profile import load_profiles
from core.matcher import score_job
from core.applier import AutoApplier
from core.exceptions import NeedsHuman
from core.scrapers.kariyer_net import KariyerNetScraper
from core.scrapers.indeed import IndeedScraper
from core.scrapers.isinolsun import IsinOlsunScraper
from core.scrapers.extra_sites import (
    LinkedInScraper, ElemanNetScraper, SecretcvScraper, IskurScraper,
    ToptalentScraper, JoobleScraper, YouthallScraper, Is24SaatScraper,
)

SITE_REGISTRY = {
    "kariyer.net": KariyerNetScraper,
    "indeed": IndeedScraper,
    "isinolsun.com": IsinOlsunScraper,
    "linkedin": LinkedInScraper,
    "eleman.net": ElemanNetScraper,
    "secretcv.com": SecretcvScraper,
    "iskur.gov.tr": IskurScraper,
    "toptalent.co": ToptalentScraper,
    "jooble.org": JoobleScraper,
    "youthall.com": YouthallScraper,
    "24saatteis.com": Is24SaatScraper,
}


class Manager:
    """Engine tarafından yönetilen otomasyon döngüsü.
    Engine'e log yazar; CAPTCHA/giriş ve onay kuyruğu akışını Engine ile koordine eder."""

    def __init__(self, browser_pair, engine):
        self.context, self.page = browser_pair
        self.engine = engine
        self.stop_event = threading.Event()
        self.thread = None

    def log(self, msg: str):
        stamp = datetime.now().strftime("%H:%M:%S")
        self.engine.log(f"[{stamp}] {msg}")

    def run_blocking(self):
        """Engine'in worker thread'inden çağrılır — Playwright aynı thread'de kalır."""
        self.stop_event.clear()
        self._run()

    def stop(self):
        self.stop_event.set()
        self.log("Durdurma sinyali gönderildi...")

    def _browser_dead(self) -> bool:
        """Tarayıcı/pencere kapatıldıysa True — otomasyon güvenle sonlanır."""
        if not self.engine.browser_open.is_set():
            return True
        try:
            _ = self.page.url  # kapalı sayfada bu raise eder
            return False
        except Exception:
            self.engine.browser_open.clear()
            return True

    def _wait_cancellable(self, event, timeout=None) -> bool:
        """Event'i bekler ama stop/tarayıcı kapanması durumunda hemen döner."""
        elapsed = 0
        while not event.wait(1.0):
            if self.stop_event.is_set() or self._browser_dead():
                return False
            elapsed += 1
            if timeout and elapsed >= timeout:
                return False

    # ---------- main loop ----------

    def _run(self):
        settings = load_settings()
        profiles = load_profiles(settings)
        if not profiles:
            self.log("[!] CV profili yok — 'CV'lerim' sekmesinden PDF seç, durduruluyor.")
            return
        search = settings.get("search", {})
        min_score = float(search.get("min_match_score", 55))
        daily_limit = int(search.get("max_applications_per_day", 12))
        approval_mode = bool(settings.get("approval_mode", False))
        auto_apply = bool(settings.get("auto_apply", False))
        if not auto_apply:
            self.log("ℹ️ Otomatik başvuru KAPALI — sistem ilanları tarayıp listeler; "
                     "başvuruları Başvurular sekmesinden elle takip edeceksin.")

        enabled = settings.get("enabled_sites", list(SITE_REGISTRY.keys()))
        scrapers = [SITE_REGISTRY[name](self.page, settings)
                    for name in enabled if name in SITE_REGISTRY]
        self.log(f"Aktif siteler ({len(scrapers)}): " + ", ".join(s.site_name for s in scrapers))
        if approval_mode:
            self.log("🟡 Onay kuyruğu modu AÇIK — her başvuru gönderilmeden önce senin onayını bekleyecek.")

        if self._browser_dead():
            self.log("[x] Tarayıcı kapalı — önce 'Tarayıcıyı Aç'.")
            return

        # --- FAZ 0: önce DB'de bekleyen ilanlara başla (anında geri bildirim) ---
        backlog = [j for j in db.all_jobs()
                   if j.get("status") == "found" and (j.get("score") or 0) >= min_score]
        backlog.sort(key=lambda j: (j.get("score") or 0), reverse=True)
        if backlog:
            self.log(f"📌 {len(backlog)} bekleyen ilan var (en yüksek skor önce).")
            if auto_apply:
                for job in backlog:
                    if self.stop_event.is_set() or self._browser_dead():
                        break
                    if db.todays_application_count() >= daily_limit:
                        self.log(f"[!] Günlük limit doldu ({daily_limit}). Yarın devam.")
                        break
                    if db.already_applied(job["url"]):
                        continue
                    if not self._city_ok(job, search.get("cities", [])):
                        db.update_status(job["url"], "found", notes="şehir dışı — atlandı")
                        continue
                    score, profile = score_job(job, profiles)
                    self._apply_job(job, profile, approval_mode, search)
            else:
                self.log("ℹ️ Otomatik başvuru kapalı — bu ilanlar Başvurular sekmesinde seni bekliyor.")
        else:
            self.log("Bekleyen ilan yok — doğrudan taramaya geçiliyor.")

        # --- FAZ 1: tarama; her arama biter bitmez uygun ilanlara başvur ---
        self.log("Tarama başlıyor (bulunan uygun ilanlara anında başvurulacak)...")
        skipped_disabled = 0
        for scraper in scrapers:
            if self.stop_event.is_set() or self._browser_dead():
                break
            for kw in search.get("keywords", []):
                if self.stop_event.is_set():
                    break
                for city in search.get("cities", []):
                    if self.stop_event.is_set():
                        break
                    try:
                        self.log(f"  {scraper.site_name} | '{kw}' @ {city}")
                        jobs = scraper.search(kw, city)
                    except NeedsHuman:
                        self.log("  🤖 Site güvenlik kontrolü istedi — yardım bekleniyor...")
                        self.engine.notify_human(f"{scraper.site_name} güvenlik kontrolü (CAPTCHA)")
                        self.engine.human_event.wait()
                        if self.stop_event.is_set():
                            break
                        try:
                            jobs = scraper.search(kw, city)
                        except Exception as e:
                            self.log(f"  [x] {scraper.site_name} tekrar deneme başarısız: {e}")
                            continue
                    except Exception as e:
                        self.log(f"  [x] {scraper.site_name} hatası: {e}")
                        continue
                    new_count = 0
                    batch = []
                    for j in jobs:
                        score, profile = score_job(j, profiles)
                        j["score"] = score
                        if db.upsert_job(j):
                            new_count += 1
                            if score >= min_score:
                                batch.append((j, profile))
                    self.log(f"  [i] {len(jobs)} ilan bulundu, {new_count} yeni, "
                             f"{len(batch)} uygun.")
                    # bulunan uygun ilanlara HEMEN başvur (yalnızca otomatik mod açıksa)
                    if auto_apply:
                        for job, profile in batch:
                            if self.stop_event.is_set() or self._browser_dead():
                                break
                            if db.todays_application_count() >= daily_limit:
                                break
                            if db.already_applied(job["url"]):
                                continue
                            if not self._city_ok(job, search.get("cities", [])):
                                db.update_status(job["url"], "found", notes="şehir dışı — atlandı")
                                continue
                            if not settings.get("apply_disabled_jobs", False) and \
                                    "engelli" in ((job.get("title") or "") + " " + (job.get("posted_text") or "")).lower():
                                skipped_disabled += 1
                                db.update_status(job["url"], "found", notes="engelli ilanı — başvuru kapalı")
                                continue
                            self._apply_job(job, profile, approval_mode, search)
                    time.sleep(random.uniform(4, 10))

        if skipped_disabled:
            self.log(f"[i] {skipped_disabled} engelli (kota) ilanı atlandı. "
                     "Başvurmak istersen: Ayarlar > 'Engelli (kota) ilanlarına da başvur'.")
        self.log("Döngü tamamlandı.")

    # ---------- sehir filtresi ----------

    def _city_ok(self, job, cities) -> bool:
        """Site sehir filtresini yoksayarsa uygulama tarafi kontrol eder.
        Konum bos ise veya listelenen sehirlerden birini/uzaktan içeriyorsa geçer."""
        if not cities:
            return True
        loc = ((job.get("location") or "") + " " + (job.get("title") or "")).lower()
        if not (job.get("location") or "").strip():
            return True  # konum bilgisi yok — siteye güven
        if any(k in loc for k in ["uzaktan", "remote", "hibrit"]):
            return True
        return any(c.lower() in loc for c in cities)

    # ---------- tek ilan başvurusu ----------

    def _apply_job(self, job, profile, approval_mode, search):
        if self._browser_dead():
            return
        self.log(f"→ Başvuruluyor: {job['title']} ({job['site']}, skor {job['score']})")
        applier = AutoApplier(self.page, load_settings(), self.log,
                              creds_provider=self.engine.get_credential)
        try:
            status = applier.apply(job, profile, approval_mode=approval_mode)
        except NeedsHuman as e:
            self.log(f"  🤖 {e.reason}")
            self.engine.notify_human(e.reason)
            # kullanıcı çözsün diye bekleyip TEKRAR BİR kez deneriz
            if not self._wait_cancellable(self.engine.human_event, timeout=600):
                self.log("  [x] Yardım beklenirken durduruldu/tarayıcı kapandı.")
                return
            if self.stop_event.is_set():
                return
            try:
                status = applier.apply(job, profile, approval_mode=approval_mode)
            except NeedsHuman as e2:
                self.log(f"  [!] Hâlâ engel var: {e2.reason} — bu ilan atlandı.")
                db.update_status(job["url"], "needs_attention", profile.name, f"insan yardımı: {e2.reason}")
                return
        except Exception as e:
            self.log(f"    [x] Hata: {e}")
            db.update_status(job["url"], "failed", profile.name if profile else "", str(e)[:200])
            return

        # onay kuyruğu
        if status == "filled_pending_approval":
            db.update_status(job["url"], "onay_bekliyor", profile.name if profile else "",
                             f"cv={profile.name}" if profile else "")
            self.engine.set_pending(job)
            self.log("  ⏸ ONAY BEKLENİYOR → 'Başvurular' sekmesinden takip et.")
            if not self._wait_cancellable(self.engine.approval_event, timeout=1800):
                self.log("  [x] Onay beklenirken durduruldu/tarayıcı kapandı — ilan 'Elle bakılmalı' işaretlendi.")
                db.update_status(job["url"], "needs_attention", profile.name if profile else "", "onay beklenirken kesildi")
                self.engine.pending_job = None
                return
            if self.engine.approved:
                status = applier.submit()
            else:
                self.log("  ❌ Kullanıcı reddetti, sıradakine geçiliyor.")
                return

        db.update_status(job["url"], status, profile.name if profile else "",
                         f"cv={profile.name}" if profile else "")
        if status == "applied":
            db.increment_daily_count()
            self.log(f"    [✅] BAŞVURU GERÇEKLEŞTİ → {job['title']} | {job['site']} | ilan sayfası: {job['url']}")
        elif status == "needs_attention":
            self.log(f"    [⚠] Otomatik başvuru tamamlanamadı (form/site farklıysa elle başvur): {job['url']}")

        dmin, dmax = search.get("delay_between_actions_sec", [20, 90])
        pause = random.uniform(float(dmin), float(dmax))
        self.log(f"  bekleniyor {int(pause)} sn...")
        for _ in range(int(pause)):
            if self.stop_event.is_set():
                break
            time.sleep(1)