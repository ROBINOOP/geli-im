import re


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def kw_hit(keyword: str, text: str) -> bool:
    """Substring match + Türkçe çekim toleransı (güvenlik→güvenliği gibi).
    Uzun kelimeler için kelime-kök eşleşmesine de bakar."""
    if keyword in text:
        return True
    if len(keyword) >= 6:
        stem = keyword[:-2]  # son 2 harfi at (k/i çekimleri)
        return any(w.startswith(stem) for w in text.split())
    return False


def score_job(job: dict, profiles) -> tuple[float, object]:
    """Return (score 0-100, best profile).

    Kalibrasyon:
      + hedef kelime ilan başlığında   → 40 taban, ek başına +8 (maks 64)
      + beceri eşleşmesi (metin)       → her biri +4 (maks 24)
      + konum uygun                    → +10
      + profil alan uyumu (domain)     → +6 (tek seferlik bonus)
    """
    title = normalize(job.get("title", ""))
    text = normalize(f"{job.get('title','')} {job.get('company','')} {job.get('posted_text','')} {job.get('description','')}")
    loc = normalize(job.get("location", ""))

    best_score, best_profile = 0.0, None
    for p in profiles:
        s = 0.0
        title_hits = sum(1 for k in p.target_keywords if kw_hit(k, title))
        if title_hits:
            s += 40 + min(title_hits - 1, 3) * 8  # 40-64
        matched_skills = [sk for sk in p.skills if sk in text]
        s += min(len(matched_skills) * 4, 24)
        if sum(1 for k in p.target_keywords if kw_hit(k, text)) >= 2:
            s += 6
        if loc and any(c.lower() in loc for c in ["ankara", "istanbul", "uzaktan", "remote", "hibrit"]):
            s += 10
        s = min(s, 100)
        if s > best_score:
            best_score, best_profile = s, p

    return round(best_score, 1), best_profile
