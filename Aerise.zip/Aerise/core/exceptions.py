"""Ortak istisnalar — UI ve motor katmanı arasında dil bağı olmadan iletişim."""


class NeedsHuman(Exception):
    """Otomasyonun kendisi çözemeyeceği durum: CAPTCHA, giriş ekranı vb.
    Motor durur, kullanıcıdan yardım ister. ASLA atlatma denenmez."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason