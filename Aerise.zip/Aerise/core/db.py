import sqlite3
import os
from datetime import datetime, date

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "jobs.db")


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                site TEXT, title TEXT, company TEXT, location TEXT,
                url TEXT UNIQUE, posted_text TEXT, score REAL,
                cv_profile TEXT, status TEXT, applied_at TEXT, notes TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS daily_stats (
                day TEXT PRIMARY KEY, applications INTEGER DEFAULT 0
            )
        """)


def upsert_job(job: dict) -> bool:
    """Returns True if job is new (inserted)."""
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT OR IGNORE INTO jobs (site,title,company,location,url,posted_text,score,status,notes) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (job.get("site"), job.get("title"), job.get("company"), job.get("location"),
             job.get("url"), job.get("posted_text"), job.get("score", 0), job.get("status", "found"), ""),
        )
        return cur.rowcount > 0


def update_status(url: str, status: str, cv_profile: str = "", notes: str = "") -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE jobs SET status=?, cv_profile=?, applied_at=?, notes=? WHERE url=?",
            (status, cv_profile, datetime.now().isoformat(timespec="seconds"), notes, url),
        )


def already_applied(url: str) -> bool:
    with get_conn() as conn:
        row = conn.execute("SELECT status FROM jobs WHERE url=?", (url,)).fetchone()
        return row is not None and row["status"] in ("applied", "needs_attention", "failed")


def todays_application_count() -> int:
    today = date.today().isoformat()
    with get_conn() as conn:
        row = conn.execute("SELECT applications FROM daily_stats WHERE day=?", (today,)).fetchone()
        return row["applications"] if row else 0


def increment_daily_count() -> int:
    today = date.today().isoformat()
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO daily_stats (day, applications) VALUES (?,1) "
            "ON CONFLICT(day) DO UPDATE SET applications = applications + 1",
            (today,),
        )
        return todays_application_count()


def delete_by_status(status: str) -> int:
    """Belirli durumdaki ilanları siler (listeyi hafifletmek için)."""
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM jobs WHERE status=?", (status,))
        return cur.rowcount


def all_jobs() -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM jobs ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]
