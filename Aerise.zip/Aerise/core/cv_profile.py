import os
import re
from pypdf import PdfReader
from core.settings import load_settings, project_root

DEFAULT_SKILL_BANK = [
    "python", "sql", "windows", "linux", "active directory", "office", "eset", "sophos",
    "fortigate", "firewall", "edr", "endpoint", "encryption", "safetica", "nas",
    "sla", "agile", "rpa", "veri bilimi", "teknik destek", "donanım", "yazılım",
    "soc", "siber güvenlik", "bilgi güvenliği", "ağ", "network", "helpdesk",
    "vmware", "exchange", "microsoft 365", "azure", "backup", "sistem uzmanı",
    "işletim sistemi", "sistem yönetimi",
]


def extract_text(pdf_path: str) -> str:
    reader = PdfReader(pdf_path)
    return "\n".join((p.extract_text() or "") for p in reader.pages)


def _auto_discover_skills(text: str) -> list[str]:
    """CV metninden bilinen kalıplarla beceri adaylarını keşfeder (kademe 2 temeli).

    Heuristikler:
      - Büyük harfle yazılan kısaltmalar (EDR, SOC, NAS, ERP...)
      - CamelCase / teknik isimler (FortiGate, ActiveDirectory)
      - 'X ile/X'te deneyim' kalıbındaki kelimeler
    Bilinen marka/araç adları çoğunlukla bu kalıplara düşer — dil bağımsızdır.
    """
    found = set()
    noise = {"ve", "ek", "ile", "için", "icin", "the", "and", "for", "cv", "pdf",
             "ii", "td", "asl", "ing", "b", "a", "kvkk", "aslinda", "not"}
    # 3-6 harfli bilinçli kısaltmalar
    for m in re.findall(r"\b[A-Z]{2,6}\b", text):
        if m.lower() not in noise and len(m) >= 3:
            found.add(m.lower())
    # CamelCase / ara boşluklu markalar
    for m in re.findall(r"\b[A-Z][a-z]+(?:[A-Z][a-z]+)+\b", text):
        found.add(m.lower())
    # Yaygın teknoloji sonekleri: -anahtar, -server, -studio vb. içerikli büyük harfli kelimeler
    for m in re.findall(r"\b(?:Microsoft|Google|Amazon|Oracle|IBM|Cisco|SAP|Vmware|VMware|Salesforce)\s+[A-ZÇĞİÖŞÜ][\wçğıöşü]+(?:\s+[A-ZÇĞİÖŞÜ][\wçğıöşü]+)?", text):
        found.add(m.lower())
    return sorted(found)[:25]


class CVProfile:
    def __init__(self, name: str, pdf_path: str, keywords: list[str], label: str = ""):
        self.name = name
        self.label = label or name
        self.pdf_path = pdf_path
        self.target_keywords = [k.lower() for k in keywords]
        path = pdf_path if os.path.isabs(pdf_path) else os.path.join(project_root(), pdf_path)
        self.text = extract_text(path) if os.path.exists(path) else ""
        bank = load_settings().get("skill_bank", DEFAULT_SKILL_BANK)
        bank = [s.lower() for s in bank]
        matched = [s for s in bank if s in self.text.lower()]
        discovered = [s for s in _auto_discover_skills(self.text) if s not in matched]
        self.skills = matched + discovered  # önce bilinenler, sonra keşfedilenler

    def matches_domain(self, job_text: str) -> int:
        jt = job_text.lower()
        return sum(1 for k in self.target_keywords if k in jt)


def load_profiles(settings: dict) -> list[CVProfile]:
    profiles = []
    for name, cfg in settings.get("cv_profiles", {}).items():
        try:
            profiles.append(CVProfile(name, cfg["path"], cfg.get("for_keywords", []),
                                      label=cfg.get("label", name)))
        except Exception as e:
            print(f"[cv] '{name}' yüklenemedi: {e}")
    return profiles
