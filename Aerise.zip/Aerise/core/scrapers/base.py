import random
import time


class ScraperError(Exception):
    pass


class BaseScraper:
    site_name = "base"

    def __init__(self, page, settings: dict):
        self.page = page  # playwright Page (already logged-in persistent context)
        self.settings = settings

    def human_pause(self, a: int = 2, b: int = 6):
        time.sleep(random.uniform(a, b))

    def wait_for_any(self, selectors: list[str], timeout_ms: int = 12000) -> bool:
        """JS ağır sitelerde listelerin render edilmesini bekler.
        Hiçbiri gelmezse False döner (yine de parse denenir)."""
        import time as _t
        deadline = _t.time() + timeout_ms / 1000
        while _t.time() < deadline:
            for sel in selectors:
                try:
                    if self.page.query_selector(sel):
                        return True
                except Exception:
                    pass
            _t.sleep(0.8)
        return False

    def goto_retry(self, url: str, tries: int = 3):
        """Site yönlendirme/iptallerine dayanıklı navigasyon.
        ERR_ABORTED gibi geçici hatalarda bekleyip tekrar dener."""
        last = None
        for i in range(tries):
            try:
                self.page.goto(url, wait_until="domcontentloaded", timeout=60000)
                return
            except Exception as e:
                last = e
                time.sleep(random.uniform(3, 6))
                try:
                    self.page.goto(url, wait_until="commit", timeout=60000)
                    return
                except Exception as e2:
                    last = e2
                    time.sleep(random.uniform(2, 4))
        raise last

    def search(self, keyword: str, city: str) -> list[dict]:
        raise NotImplementedError

    def safe_text(self, selector: str) -> str:
        try:
            el = self.page.query_selector(selector)
            return el.inner_text().strip() if el else ""
        except Exception:
            return ""

    def safe_attr(self, selector: str, attr: str) -> str:
        try:
            el = self.page.query_selector(selector)
            return el.get_attribute(attr) or "" if el else ""
        except Exception:
            return ""
