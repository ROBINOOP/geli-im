import urllib.parse
from core.scrapers.base import BaseScraper


class IsinOlsunScraper(BaseScraper):
    site_name = "isinolsun.com"
    base = "https://www.isinolsun.com"

    def search(self, keyword: str, city: str) -> list[dict]:
        q = urllib.parse.quote(keyword)
        url = f"{self.base}/is-ilanlari?f_6={q}"
        if city.lower() != "uzaktan":
            url += f"&f_2={urllib.parse.quote(city)}"
        self.goto_retry(url)
        self.human_pause(3, 6)
        self.wait_for_any(["a[href*='/is-ilani/']", "a[data-testid='job-card']"], 12000)

        jobs, seen = [], set()
        cards = self.page.query_selector_all("a[href*='/is-ilani/'], a[data-testid='job-card']")
        for card in cards[:30]:
            href = card.get_attribute("href") or ""
            if not href:
                continue
            link = href if href.startswith("http") else self.base + href
            if link in seen:
                continue
            seen.add(link)
            jobs.append({
                "site": self.site_name,
                "title": (card.inner_text() or "").split("\n")[0].strip()[:120],
                "company": "",
                "location": city,
                "url": link,
                "posted_text": "",
            })
        return jobs
