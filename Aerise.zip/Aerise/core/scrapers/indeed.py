import urllib.parse
from core.scrapers.base import BaseScraper


class IndeedScraper(BaseScraper):
    site_name = "indeed"
    base = "https://tr.indeed.com"

    def search(self, keyword: str, city: str) -> list[dict]:
        q = urllib.parse.quote(keyword)
        loc = urllib.parse.quote(city if city.lower() != "uzaktan" else "")
        url = f"{self.base}/jobs?q={q}"
        url += f"&l={loc}" if loc else "&sc=0kf%3Aattr(DSQF7)"
        self.goto_retry(url)
        self.human_pause(3, 6)
        self.wait_for_any(["div.job_seen_beacon", "td.resultContent", "h2 a[data-jk]"], 15000)

        jobs, seen = [], set()
        cards = self.page.query_selector_all("div.job_seen_beacon, td.resultContent")
        for card in cards[:30]:
            a = card.query_selector("h2 a, a[data-jk]")
            if not a:
                continue
            href = a.get_attribute("href") or ""
            link = href if href.startswith("http") else self.base + href
            if link in seen:
                continue
            seen.add(link)
            company = self.safe_text_in(card, "span.companyName, [data-testid='company-name']")
            location = self.safe_text_in(card, "div.companyLocation, [data-testid='job-location']")
            jobs.append({
                "site": self.site_name,
                "title": (a.inner_text() or "").strip()[:120],
                "company": company,
                "location": location or city,
                "url": link,
                "posted_text": self.safe_text_in(card, "span.date, [data-testid='myJobsStateDate']"),
            })
        return jobs

    def safe_text_in(self, element, selector: str) -> str:
        try:
            el = element.query_selector(selector)
            return el.inner_text().strip() if el else ""
        except Exception:
            return ""
