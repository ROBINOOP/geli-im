import urllib.parse
from core.scrapers.base import BaseScraper


class KariyerNetScraper(BaseScraper):
    site_name = "kariyer.net"
    base = "https://www.kariyer.net"

    def search(self, keyword: str, city: str) -> list[dict]:
        q = urllib.parse.quote(keyword)
        loc = urllib.parse.quote(city) if city.lower() != "uzaktan" else ""
        url = f"{self.base}/is-ilanlari?kw={q}"
        if loc:
            url += f"&cp={loc}"
        if city.lower() == "uzaktan":
            url += "&wkt=2"  # uzaktan çalışma filtresi

        self.goto_retry(url)
        self.human_pause(3, 6)

        jobs, seen = [], set()
        # Listing cards; selectors may need updates if site changes markup
        cards = self.page.query_selector_all("a[data-element-name='job-item'], .job-item a, a[href*='/is-ilani/']")
        for card in cards[:30]:
            href = card.get_attribute("href") or ""
            if not href:
                continue
            link = href if href.startswith("http") else self.base + href
            if link in seen:
                continue
            seen.add(link)
            jobs.append({
                "site": self.site_name,
                "title": (card.inner_text() or "").split("\n")[0].strip()[:120],
                "company": "",
                "location": city,
                "url": link,
                "posted_text": "",
            })
        return jobs
