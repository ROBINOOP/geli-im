"""Ek iş sitesi tarayıcıları: LinkedIn, Eleman.net, Secretcv, İŞKUR,
Toptalent, Jooble, Youthall, 24 Saatte İş.

Her tarayıcı BaseScraper arayüzünü uygular. Site arayüzü değişirse
yalnızca ilgili sınıftaki URL/seçiciler güncellenir.
"""
import urllib.parse
from core.scrapers.base import BaseScraper


class _GenericScraper(BaseScraper):
    """Ortak mantık: arama URL'sine git, belirtilen desenle eşleşen ilan linklerini topla."""
    search_tpl = ""
    link_pattern = ""
    title_split = True

    def search(self, keyword: str, city: str) -> list[dict]:
        url = self.search_tpl.format(
            q=urllib.parse.quote(keyword),
            city=urllib.parse.quote(city if city.lower() != "uzaktan" else ""),
            remote="1" if city.lower() == "uzaktan" else "",
        )
        self.goto_retry(url)
        self.human_pause(3, 7)
        self.wait_for_any([f"a[href*='{self.link_pattern}']"], 10000)

        jobs, seen = [], set()
        cards = self.page.query_selector_all("a[href]")
        for card in cards:
            href = card.get_attribute("href") or ""
            if self.link_pattern not in href:
                continue
            link = href if href.startswith("http") else self.base + href
            # parametre temizliği (takip/utm)
            link = link.split("?")[0]
            if link in seen:
                continue
            seen.add(link)
            text = (card.inner_text() or "").strip()
            if not text:
                continue
            title = text.split("\n")[0].strip()[:130] if self.title_split else text[:130]
            if len(title) < 4:
                continue
            jobs.append({
                "site": self.site_name,
                "title": title,
                "company": text.split("\n")[1].strip()[:80] if "\n" in text and len(text.split("\n")) > 1 else "",
                "location": city,
                "url": link,
                "posted_text": "",
            })
            if len(jobs) >= 30:
                break
        return jobs


class LinkedInScraper(_GenericScraper):
    """LinkedIn misafir (guest) iş arama görünümü. Hesap girişi gerekmez;
    tarayıcı penceresinde elle giriş yapılmışsa sonuçlar daha zengin olur."""
    site_name = "linkedin"
    base = "https://www.linkedin.com"
    search_tpl = "https://www.linkedin.com/jobs/search/?keywords={q}&location={city}&f_WT=2"
    link_pattern = "/jobs/view/"


class ElemanNetScraper(_GenericScraper):
    site_name = "eleman.net"
    base = "https://eleman.net"
    search_tpl = "https://eleman.net/ara?query={q}"
    link_pattern = "/ilan/"


class SecretcvScraper(_GenericScraper):
    site_name = "secretcv.com"
    base = "https://www.secretcv.com"
    search_tpl = "https://www.secretcv.com/is-ilanlari/?q={q}"
    link_pattern = "/is-ilanlari/detay"


class IskurScraper(_GenericScraper):
    site_name = "iskur.gov.tr"
    base = "https://www.iskur.gov.tr"
    search_tpl = "https://www.iskur.gov.tr/is-arayan/is-arama?kelime={q}"
    link_pattern = "/is-arama/detay"


class ToptalentScraper(_GenericScraper):
    site_name = "toptalent.co"
    base = "https://toptalent.co"
    search_tpl = "https://toptalent.co/ilanlar?search={q}"
    link_pattern = "/ilan/"


class JoobleScraper(_GenericScraper):
    site_name = "jooble.org"
    base = "https://tr.jooble.org"
    search_tpl = "https://tr.jooble.org/SearchResult?ukw={q}"
    link_pattern = "//"


class YouthallScraper(_GenericScraper):
    site_name = "youthall.com"
    base = "https://youthall.com"
    search_tpl = "https://youthall.com/jobs?search={q}"
    link_pattern = "/jobs/"


class Is24SaatScraper(_GenericScraper):
    site_name = "24saatteis.com"
    base = "https://24saatteis.com"
    search_tpl = "https://24saatteis.com/?s={q}"
    link_pattern = "/ilan/"