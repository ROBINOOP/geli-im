"""Aerise Engine — UI ile otomasyon arasındaki tek bağlantı noktası (facade/adapter).

Mimari:
  UI (main.py)  ──▶  Engine (bu dosya)  ──▶  Manager → Scraper/Applier adapter'ları

PLAYWRIGHT THREAD KURALI:
Playwright sync API nesneleri YALNIZCA onları oluşturan thread'de kullanılabilir.
Bu yüzden tüm Playwright işleri tek bir worker thread'de, komut kuyruğuyla sırayla yürütülür:
  UI thread ──(komut kuyruğu)──▶ Worker thread: launch → login → automation → close
"""
import os
import shutil
import queue
import random
import threading
import logging
import time
from logging.handlers import RotatingFileHandler

import keyring

from core.settings import load_settings, save_settings, project_root
from core import db

APP_NAME = "Aerise"
APP_VERSION = "1.1.0"
KEYRING_SERVICE = "Aileron"
LOG_DIR = os.path.join(project_root(), "logs")
LOG_FILE = os.path.join(LOG_DIR, "aileron.log")

# Site giriş/ana sayfaları — tarayıcı açılınca aktif siteler için sekmeler açılır
SITE_LOGIN_URLS = {
    "kariyer.net": "https://www.kariyer.net/aday/giris",
    "indeed": "https://secure.indeed.com/auth?hl=tr",
    "isinolsun.com": "https://www.isinolsun.com/",
    "linkedin": "https://www.linkedin.com/login",
    "eleman.net": "https://eleman.net/",
    "secretcv.com": "https://www.secretcv.com/giris.html",
    "iskur.gov.tr": "https://www.iskur.gov.tr/",
    "toptalent.co": "https://toptalent.co/",
    "jooble.org": "https://tr.jooble.org/",
    "youthall.com": "https://youthall.com/",
    "24saatteis.com": "https://24saatteis.com/",
}


def _setup_file_logger() -> logging.Logger:
    os.makedirs(LOG_DIR, exist_ok=True)
    logger = logging.getLogger("aileron")
    if not logger.handlers:
        handler = RotatingFileHandler(LOG_FILE, maxBytes=512_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


class Engine:
    """UI'nin kullandığı tek API. Tüm Playwright işleri worker thread'de yürütülür."""

    def __init__(self):
        self.logger = _setup_file_logger()
        self._manager = None
        self._pw = None
        self._ctx = None
        self.browser_pair = None
        self.browser_open = threading.Event()

        self.human_event = threading.Event()      # CAPTCHA/giriş: kullanıcı çözdü mü?
        self.human_reason = ""
        self.approval_event = threading.Event()   # onay kuyruğu
        self.approved = False
        self.pending_job = None
        self._ui_listeners = []
        self.status_listeners = []                # site durum değişince UI bilgilendirilir
        self.site_status = {}                     # {site: logged_in|logged_out|unknown}
        self._busy = threading.Event()            # worker otomasyon çalışıyor mu?

        # tek worker thread: TÜM playwright işleri burada
        self._q = queue.Queue()
        threading.Thread(target=self._worker_loop, daemon=True, name="aileron-worker").start()

    # ---------- log ----------

    def add_listener(self, fn):
        self._ui_listeners.append(fn)

    def add_status_listener(self, fn):
        self.status_listeners.append(fn)

    def _notify_status(self):
        for fn in list(self.status_listeners):
            try:
                fn(dict(self.site_status))
            except Exception:
                pass

    def log(self, msg: str, level="info"):
        self.logger.log(logging.INFO if level == "info" else logging.WARNING, msg)
        for fn in list(self._ui_listeners):
            try:
                fn(msg)
            except Exception:
                pass

    def clear_logs(self):
        try:
            self.logger.handlers[0].doRollover()
        except Exception:
            pass
        for i in range(1, 4):
            p = f"{LOG_FILE}.{i}"
            if os.path.exists(p):
                os.remove(p)
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write(f"{APP_NAME} log temizlendi\n")
        self.log("[✓] Loglar temizlendi.")

    # ---------- worker (tek playwright thread'i) ----------

    def _worker_loop(self):
        while True:
            cmd = self._q.get()
            try:
                handler = getattr(self, f"_do_{cmd['op']}")
                handler(cmd)
            except Exception as e:
                self.log(f"[x] Worker hatası ({cmd.get('op')}): {e}", "warning")

    def _post(self, op: str, **kw):
        self._q.put({"op": op, **kw})

    # ---------- tarayıcı ----------

    # Bot tespitini azaltan tarayıcı imza ayarları (atlatma değil, düzgün kimlik):
    STEALTH_JS = """
        Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
        window.chrome = window.chrome || { runtime: {} };
        Object.defineProperty(navigator, 'languages', {get: () => ['tr-TR', 'tr', 'en-US', 'en']});
        Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
        Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
    """

    def launch_browser(self):
        self._post("launch")

    def _do_launch(self, cmd):
        if self.browser_open.is_set():
            self.log("Tarayıcı zaten açık.")
            return
        from playwright.sync_api import sync_playwright
        settings = load_settings()
        self._pw = sync_playwright().start()
        profile_dir = os.path.join(project_root(), settings.get("browser_profile_dir", "browser_data"))
        last_err = None
        for channel in ["chrome", "msedge", None]:
            try:
                kwargs = dict(headless=False, locale="tr-TR", timezone_id="Europe/Istanbul",
                              args=["--disable-blink-features=AutomationControlled", "--start-maximized",
                                    "--lang=tr-TR"],
                              ignore_default_args=["--enable-automation"])
                if channel:
                    kwargs["channel"] = channel
                    kwargs["viewport"] = None
                self._ctx = self._pw.chromium.launch_persistent_context(profile_dir, **kwargs)
                self.log(f"🌐 Tarayıcı motoru: {channel or 'chromium'}")
                break
            except Exception as e:
                last_err = e
                self._ctx = None
        if self._ctx is None:
            raise RuntimeError(f"Tarayıcı başlatılamadı: {last_err}")
        self._ctx.add_init_script(self.STEALTH_JS)
        page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
        self.browser_pair = (self._ctx, page)
        self.browser_open.set()

        # aktif siteler için giriş sekmelerini aç
        enabled = settings.get("enabled_sites", list(SITE_LOGIN_URLS.keys()))
        urls = [SITE_LOGIN_URLS[s] for s in enabled if s in SITE_LOGIN_URLS][:6]
        if not urls:
            urls = [SITE_LOGIN_URLS["kariyer.net"]]
        page.goto(urls[0])
        for u in urls[1:]:
            try:
                p2 = self._ctx.new_page()
                p2.goto(u)
            except Exception:
                pass
        self.log(f"🌐 Tarayıcı açıldı — {len(urls)} site sekmesi açıldı. "
                 f"Her sekmede oturumunu aç (oturumlar kalıcıdır).")
        # açılış sonrası otomatik bağlantı durumu taraması
        self._post("check_sites")

    def close_browser(self):
        self._post("close")

    def _do_close(self, cmd):
        try:
            if self._ctx:
                self._ctx.close()
            if self._pw:
                self._pw.stop()
        finally:
            self._ctx = None
            self._pw = None
            self.browser_pair = None
            self.browser_open.clear()
            self.log("Tarayıcı kapatıldı.")

    # ---------- otomasyon ----------

    def start_automation(self):
        if not self.browser_open.is_set():
            raise RuntimeError("Tarayıcı açık değil.")
        if self._busy.is_set():
            raise RuntimeError("Otomasyon zaten çalışıyor.")
        # busy'i HEMEN işaretle: komut kuyrukta beklerken UI yanlış 'bitti' sanmasın
        self._busy.set()
        self.human_event.clear()
        self.approval_event.clear()
        self._post("start")

    def _do_start(self, cmd):
        from core.manager import Manager  # geç import: döngüsel bağımlılık önlenir
        try:
            self._manager = Manager(self.browser_pair, self)
            self._manager.run_blocking()   # worker thread'inde SENKRON çalışır
        finally:
            self._busy.clear()
            self._manager = None

    def stop_automation(self):
        if self._manager:
            self._manager.stop()
        # bekleyen olayları serbest bırak ki worker kilitlenmesin
        self.human_event.set()
        self.approval_event.set()

    # ---------- insan yardımı (CAPTCHA / giriş) ----------

    def notify_human(self, reason: str):
        self.human_reason = reason
        self.human_event.clear()
        self.log(f"🤖 YARDIM GEREKLİ: {reason} — sen çözdükten sonra 'Devam Et'e bas.", "warning")

    def human_resolved(self):
        self.human_reason = ""
        self.human_event.set()

    # ---------- onay kuyruğu ----------

    def set_pending(self, job: dict):
        self.pending_job = job
        self.approved = False
        self.approval_event.clear()
        self._notify_status()  # UI'daki Onay Kuyruğu panelini anında güncelle

    def approve_pending(self):
        self.approved = True
        self.approval_event.set()
        self.log("✅ Başvuru onaylandı, gönderiliyor...")

    def reject_pending(self):
        self.approved = False
        self.approval_event.set()
        if self.pending_job:
            db.update_status(self.pending_job["url"], "rejected", notes="kullanıcı reddetti")
            self.log(f"❌ Reddedildi: {self.pending_job.get('title')}")
        self.pending_job = None

    # ---------- site bağlantı durumu ----------

    _LOGGED_IN_HINTS = ["çıkış yap", "cikis yap", "hesabım", "hesabim", "profilim",
                        "hesabim", "my account", "sign out", "log out", "logout",
                        "çıkış", "merhaba,"]
    _LOGGED_OUT_HINTS = ["giriş yap", "üye ol", "uye ol", "sign in", "sign up",
                         "log in", "şifremi unuttum", "sifremi unuttum"]

    def check_site_status(self):
        """UI'dan çağrılır; worker kuyruğuna durum kontrolü komutu koyar."""
        if not self.browser_open.is_set():
            self.log("[!] Durum kontrolü için önce tarayıcıyı aç.", "warning")
            return
        if self._busy.is_set():
            self.log("[!] Otomasyon çalışıyor — durum kontrolü otomasyon bitince yapılmalı.", "warning")
            return
        self._post("check_sites")

    # Siteye özel giriş sinyalleri — JS ağır siteler için kesin ipuçları
    SITE_LOGIN_HINTS = {
        "indeed": {"in": ["merhaba", "hesabım", "myjobs", "çıkış"], "out": ["giriş yap", "create account", "üye ol"]},
        "eleman.net": {"in": ["çıkış yap", "hesabım", "başvurularım"], "out": ["giriş yap", "üye ol"]},
        "iskur.gov.tr": {"in": ["çıkış", "hesabım", "e-devlet kapım"], "out": ["giriş yap", "e-devlet ile giriş"]},
        "jooble.org": {"in": ["çıkış", "profil", "merhaba"], "out": ["giriş", "log in"]},
        "24saatteis.com": {"in": ["çıkış", "panelim", "profilim"], "out": ["giriş yap", "kayıt ol"]},
    }

    def _site_login_state(self, page, url: str, site: str = "") -> str:
        """Ana sayfadaki metin/bağlantılardan oturum durumu tahmini.
        JS'nin render etmesi için networkidle'a kadar bekler; CAPTCHA vs. ile
        karşılaşılırsa 'unknown' döner (asla etkileşim yok)."""
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=45000)
            try:
                page.wait_for_load_state("networkidle", timeout=12000)
            except Exception:
                pass
            time.sleep(random.uniform(2, 4))
            texts = page.eval_on_selector_all(
                "a, button, [role='button']",
                "els => els.map(e => ((e.innerText || '') + '|' + (e.href || '')).toLowerCase())")
            joined = " ".join(texts)
            html = (page.content() or "").lower()

            # siteye özel ipuçları önce bakılır (en güvenilir)
            hints = self.SITE_LOGIN_HINTS.get(site, {})
            if hints:
                if any(h in joined or h in html for h in hints["in"]):
                    return "logged_in"
                if any(h in joined or h in html for h in hints["out"]):
                    return "logged_out"

            hrefs = joined  # href'ler de bu listede
            logged_in = any(h in hrefs for h in self._LOGGED_IN_HINTS) or \
                        any(k in hrefs for k in ["logout", "cikis", "çıkış", "/hesabim", "/hesabım", "signout"])
            logged_out = any(h in hrefs for h in self._LOGGED_OUT_HINTS)
            if logged_in and not logged_out:
                return "logged_in"
            if logged_in and logged_out:
                return "logged_in" if any(h in hrefs for h in ["çıkış", "hesab", "profilim", "logout"]) else "logged_out"
            if logged_out:
                return "logged_out"
            return "unknown"
        except Exception:
            return "unknown"

    def _do_check_sites(self, cmd):
        settings = load_settings()
        enabled = settings.get("enabled_sites", list(SITE_LOGIN_URLS.keys()))
        page = self._ctx.new_page()
        try:
            for site in enabled:
                url = SITE_LOGIN_URLS.get(site)
                if not url:
                    continue
                state = self._site_login_state(page, url, site)
                self.site_status[site] = state
                mark = {"logged_in": "✅", "logged_out": "❌", "unknown": "❓"}[state]
                self.log(f"{mark} {site}: " + {"logged_in": "girişli",
                                                "logged_out": "giriş yapılmamış",
                                                "unknown": "belirsiz"}[state])
        finally:
            try:
                page.close()
            except Exception:
                pass
        self._notify_status()

    @property
    def is_running(self) -> bool:
        return self._busy.is_set()

    @property
    def approval_mode(self) -> bool:
        return bool(load_settings().get("approval_mode", False))

    # ---------- kimlik bilgileri (keyring) ----------

    def set_credential(self, site: str, email: str, password: str):
        keyring.set_password(KEYRING_SERVICE, f"{site}:email", email)
        keyring.set_password(KEYRING_SERVICE, f"{site}:password", password)
        self.log(f"[🔐] {site} kimlik bilgileri Windows Kimlik Yöneticisi'ne kaydedildi.")

    def get_credential(self, site: str):
        email = keyring.get_password(KEYRING_SERVICE, f"{site}:email")
        password = keyring.get_password(KEYRING_SERVICE, f"{site}:password")
        return (email, password) if email and password else None

    def delete_credential(self, site: str):
        for suffix in ("email", "password"):
            try:
                keyring.delete_password(KEYRING_SERVICE, f"{site}:{suffix}")
            except Exception:
                pass

    # ---------- KVKK ----------

    @property
    def kvkk_accepted(self) -> bool:
        return bool(load_settings().get("kvkk_accepted", False))

    def accept_kvkk(self):
        s = load_settings()
        s["kvkk_accepted"] = True
        save_settings(s)

    def reset_profile_data(self):
        if self._manager:
            self.stop_automation()
        self.close_browser()
        base = project_root()
        for path in ["browser_data", "logs", os.path.join(base, "jobs.db")]:
            full = path if os.path.isabs(path) else os.path.join(base, path)
            if os.path.isdir(full):
                shutil.rmtree(full, ignore_errors=True)
            elif os.path.exists(full):
                os.remove(full)
        self.log("[✓] Tüm yerel veri silindi (tarayıcı oturumları, loglar, ilan veritabanı).")


# global singleton — UI bunu kullanır
engine = Engine()