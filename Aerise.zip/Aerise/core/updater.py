"""Aerise güncelleme kontrolü.

Kullanıcı verisi asla gönderilmez; yalnızca sürüm numarası karşılaştırılır.
Sunucu adresi settings.json > update_url ile değiştirilebilir.
"""
import json
import urllib.request

from core.engine import APP_VERSION

DEFAULT_UPDATE_URL = "https://updates.aerise.app/latest.json"


def _semver_tuple(v: str):
    try:
        return tuple(int(x) for x in v.split("."))
    except Exception:
        return (0, 0, 0)


def check_update(update_url: str | None = None, timeout: int = 5) -> dict:
    """Return: {'status': 'up_to_date'|'available'|'error', 'latest': str|None,
    'url': str|None, 'message': str}"""
    url = update_url or DEFAULT_UPDATE_URL
    try:
        req = urllib.request.Request(url, headers={"User-Agent": f"Aerise/{APP_VERSION}"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        latest = str(data.get("version", "")).strip()
        download = data.get("download_url")
        if latest and _semver_tuple(latest) > _semver_tuple(APP_VERSION):
            return {"status": "available", "latest": latest, "url": download,
                    "message": f"Yeni sürüm {latest} mevcut."}
        return {"status": "up_to_date", "latest": latest or APP_VERSION, "url": None,
                "message": "Uygulama güncel."}
    except Exception as e:
        return {"status": "error", "latest": None, "url": None,
                "message": f"Sunucuya ulaşılamadı ({e.__class__.__name__}). "
                           f"update_url ayarını kontrol et."}