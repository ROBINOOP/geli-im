# Aerise ✈️ — Akıllı İş Başvuru Asistanı

CV'ini analiz eder, 11 iş sitesini tarar, uygun ilanlara başvurur (tam otomatik veya onay kuyruğu modunda).

## Kurulum

```bash
cd is-basvuru-otomasyonu
pip install -r requirements.txt
playwright install chromium
python main.py
```

## İlk Kullanım (sadece bir kez)

1. **Ayarlar sekmesi:** Ad, e-posta, telefon, şehir ve ön yazını gir → Kaydet.
2. **Kontrol sekmesi:** "Tarayıcıyı Aç" → açılan Chromium penceresinde Kariyer.net / Indeed / İşin Olsun'a **elle giriş yap**. Oturum `browser_data` klasöründe kalıcıdır — bir daha girmene gerek yok.
3. **"▶ Başlat"** → uygulama kendi kendine: tarar → puanlar → başvurur → kaydeder.

## Nasıl Çalışır

| Modül | İş |
|---|---|
| `core/cv_profile.py` | 2 CV'ni okur, beceri seti çıkarır |
| `core/scrapers/` | Kariyer.net, Indeed, İşin Olsun tarama |
| `core/matcher.py` | İlan ↔ CV uygunluk skoru (0–100) |
| `core/applier.py` | Form doldurma + CV yükleme + gönderim (insan benzeri yazma hızı) |
| `core/db.py` | Tüm ilanlar ve başvuru geçmişi SQLite'ta |
| `core/manager.py` | Tüm akışı yöneten döngü |

## Güvenlik / Koruma

- **Günlük başvuru limiti:** 12 (settings.json'dan ayarlanır)
- **Rastgele bekleme:** başvurular arası 20–90 sn (bot tespitini azaltır)
- **Tekrar engeli:** aynı ilana bir daha başvurmaz (DB üzerinden)
- **CV eşleştirme:** güvenlik ilanlarına Siber Güvenlik CV'si, diğerlerine BT Destek CV'si gider

## Ayarlar (`config/settings.json`)

- `search.keywords` — aranacak pozisyonlar
- `search.cities` — şehirler + "Uzaktan"
- `search.min_match_score` — bu skorun altındaki ilanlara başvurulmaz (varsayılan 55)
- `search.max_applications_per_day` — günlük başvuru limiti

## Notlar

- Site arayüzleri değişirse `core/scrapers/*` içindeki seçicileri güncellemek gerekebilir.
- Uygulama tamamen **lokal** çalışır; verilerin dışarı çıkmaz.
